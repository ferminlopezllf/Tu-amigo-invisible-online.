// Supabase Edge Function: "gift-ideas"
// Genera ideas de regalo con Claude.
//
// Dos usos:
//  1) Participante tras el sorteo (envía su código personal): la base de datos comprueba el
//     código, gasta 1 uso de su límite diario (20) y nos da la lista de deseos de SU amigo invisible.
//  2) Apartado público "Ideas de regalo" (sin código): límite de 10 peticiones al día por visitante
//     y 300 al día en total, para que el gasto de la IA nunca se dispare.
//
// La clave de Anthropic vive SOLO aquí, como secreto (ANTHROPIC_API_KEY); nunca llega al navegador.
// Despliegue: README.md, paso 5. Esta función debe tener desactivado "Verify JWT".

const MODEL = Deno.env.get('ANTHROPIC_MODEL') ?? 'claude-haiku-5-5'
const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const reply = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type': 'application/json' } })

type Wishlist = { wants?: string; hobbies?: string; dislikes?: string; about?: string }

// Copia de src/lib/giftPrompt.js
function buildGiftPrompt(o: {
  receiverName?: string; recipient: string; wishlist: Wishlist; profile: string; traits: string[];
  priceMin: number | null; priceMax: number; avoid: string[]
}) {
  const w = o.wishlist || {}
  const who = o.receiverName || o.recipient || 'esta persona'
  const price = o.priceMin
    ? `- Cada idea debe costar ENTRE ${o.priceMin} € y ${o.priceMax} € (precio aproximado realista en España). No propongas nada más barato ni más caro.`
    : `- Cada idea debe costar como MÁXIMO ${o.priceMax} € (precio aproximado realista en España).`
  const lines = [
    'Eres un asesor de regalos experto para regalos de Navidad y amigo invisible en España.',
    `Propón 6 ideas de regalo concretas y variadas para ${who}.`,
    '',
    'REGLAS:',
    price,
    '- Variedad: mezcla algo práctico, una experiencia o actividad, algo personalizado o hecho con cariño, algo relacionado con sus aficiones y algún detalle original.',
    '- Ideas específicas (no "un libro", sino qué tipo de libro o un ejemplo concreto), que se puedan comprar en tiendas físicas u online habituales en España.',
    '- Respeta lo que NO quiere recibir. No propongas nada inapropiado para un regalo entre amigos, familia o compañeros.',
    '- Escribe en español, en tono cercano y breve.',
    '',
    'LO QUE SABEMOS DE LA PERSONA:',
  ]
  if (o.recipient?.trim() && o.receiverName) lines.push(`- Quién es: ${o.recipient.trim()}`)
  if (o.recipient?.trim() && !o.receiverName) lines.push(`- Para quién es el regalo: ${o.recipient.trim()}`)
  if (o.profile?.trim()) lines.push(`- Cómo la describe quien le regala: ${o.profile.trim()}`)
  if (o.traits.length) lines.push(`- Rasgos: ${o.traits.join(', ')}`)
  if (w.wants?.trim()) lines.push(`- Le gustaría recibir: ${w.wants.trim()}`)
  if (w.hobbies?.trim()) lines.push(`- Aficiones: ${w.hobbies.trim()}`)
  if (w.dislikes?.trim()) lines.push(`- NO quiere recibir: ${w.dislikes.trim()}`)
  if (w.about?.trim()) lines.push(`- Sobre sus gustos: ${w.about.trim()}`)
  if (!o.profile?.trim() && !o.traits.length && !o.recipient?.trim() && !Object.values(w).some((v) => v?.trim())) {
    lines.push('- No sabemos casi nada: propone ideas universales que gusten a casi todo el mundo.')
  }
  if (o.avoid.length) lines.push('', `No repitas estas ideas ya propuestas: ${o.avoid.join('; ')}.`)
  lines.push(
    '',
    'Responde SOLO con JSON válido, sin texto antes ni después, con esta forma exacta:',
    '{"ideas":[{"titulo":"…","descripcion":"una frase con qué es exactamente","precio":25,"por_que":"una frase de por qué encaja con su personalidad","donde":"tipo de tienda o web donde encontrarlo"}]}',
  )
  return lines.join('\n')
}

async function sha256(text: string) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return Array.from(new Uint8Array(buf), (b) => b.toString(16).padStart(2, '0')).join('')
}

async function callRpc(fn: string, params: unknown, key: string) {
  const res = await fetch(`${Deno.env.get('SUPABASE_URL')}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  })
  const data = await res.json().catch(() => null)
  return { ok: res.ok, data }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors })
  if (req.method !== 'POST') return reply(405, { error: 'Método no permitido' })

  const apiKey = Deno.env.get('ANTHROPIC_API_KEY')
  if (!apiKey) return reply(500, { error: 'Falta configurar la clave de la IA (ANTHROPIC_API_KEY) en Supabase.' })

  let body: Record<string, unknown>
  try { body = await req.json() } catch { return reply(400, { error: 'Petición no válida' }) }

  const str = (v: unknown, n: number) => String(v ?? '').slice(0, n)
  const list = (v: unknown, n: number, len: number) => (Array.isArray(v) ? v : []).map(String).slice(0, n).map((t) => t.slice(0, len))
  const code = str(body.code, 40)
  const recipient = str(body.recipient, 80)
  const profile = str(body.profile, 1500)
  const traits = list(body.traits, 12, 30)
  const avoid = list(body.avoid, 24, 80)
  const priceMax = Math.round(Number(body.priceMax))
  const priceMin = body.priceMin == null ? null : Math.round(Number(body.priceMin))
  if (!(priceMax >= 1 && priceMax <= 5000)) return reply(400, { error: 'Elige un precio válido' })
  if (priceMin != null && !(priceMin >= 1 && priceMin < priceMax)) return reply(400, { error: 'El intervalo de precio no es válido' })

  let receiverName: string | undefined
  let wishlist: Wishlist = {}

  if (code) {
    // 1) Participante: comprueba el código y trae los datos de SU amigo invisible
    const anon = Deno.env.get('SUPABASE_ANON_KEY')!
    const ctx = await callRpc('gift_ideas_context', { p_code: code }, anon)
    if (!ctx.ok) return reply(403, { error: ctx.data?.message ?? 'No autorizado' })
    receiverName = ctx.data.receiver_name
    wishlist = ctx.data.wishlist
  } else {
    // 2) Público: límite por visitante (huella anónima) y límite global diario
    const ip = (req.headers.get('x-forwarded-for') ?? '').split(',')[0].trim() || 'desconocido'
    const client = await sha256(`${ip}|${req.headers.get('user-agent') ?? ''}|${Deno.env.get('IDEAS_SALT') ?? 'amigo-invisible'}`)
    const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const quota = await callRpc('gift_ideas_public_quota', { p_client: client }, service)
    if (!quota.ok) return reply(429, { error: quota.data?.message ?? 'Demasiadas peticiones. Vuelve más tarde.' })
  }

  const prompt = buildGiftPrompt({ receiverName, recipient, wishlist, profile, traits, priceMin, priceMax, avoid })
  const aiRes = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: MODEL, max_tokens: 1800, messages: [{ role: 'user', content: prompt }] }),
  })
  if (!aiRes.ok) {
    console.error('Anthropic error', aiRes.status, await aiRes.text())
    return reply(502, { error: 'La IA no está disponible ahora mismo. Inténtalo en un momento.' })
  }
  const ai = await aiRes.json()
  const text: string = (ai.content ?? []).filter((c: { type: string }) => c.type === 'text').map((c: { text: string }) => c.text).join('')
  const match = text.match(/\{[\s\S]*\}/)
  try {
    const parsed = JSON.parse(match ? match[0] : text)
    return reply(200, { ideas: parsed.ideas ?? [] })
  } catch {
    return reply(502, { error: 'La IA devolvió una respuesta extraña. Vuelve a intentarlo.' })
  }
})
