import { useEffect, useState } from 'react'

// Router por "hash" (#/ruta): funciona en cualquier hosting estático sin configuración extra.
// En la vista previa (VITE_DEMO=1) la ruta se guarda en memoria, porque la página
// se muestra dentro de un marco que no admite rutas en el hash.
const DEMO = import.meta.env.VITE_DEMO === '1'
let memPath = '/'
const listeners = new Set()

function parse(raw) {
  const [path, query = ''] = (raw || '/').split('?')
  const parts = path.split('/').filter(Boolean)
  return { path, parts, query: new URLSearchParams(query) }
}
const current = () => parse(DEMO ? memPath : window.location.hash.replace(/^#/, ''))

export function navigate(to) {
  if (DEMO) {
    memPath = to
    listeners.forEach((l) => l())
    window.scrollTo({ top: 0 })
  } else {
    window.location.hash = to
  }
}

if (DEMO && typeof document !== 'undefined') {
  // Los enlaces internos (<a href="#/...">) se gestionan en memoria
  document.addEventListener('click', (e) => {
    const a = e.target.closest?.('a[href^="#/"]')
    if (!a) return
    e.preventDefault()
    navigate(a.getAttribute('href').slice(1))
  })
}

export function useRoute() {
  const [route, setRoute] = useState(current)
  useEffect(() => {
    const onChange = () => { setRoute(current()); if (!DEMO) window.scrollTo({ top: 0 }) }
    if (DEMO) { listeners.add(onChange); return () => listeners.delete(onChange) }
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return route
}
