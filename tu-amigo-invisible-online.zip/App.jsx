import { useRoute } from './router'
import { isConfigured } from './api'
import { Layout, ErrorScreen } from './ui'
import Home from './Home'
import CreateGroup from './CreateGroup'
import Admin from './Admin'
import Join from './Join'
import Me from './Me'
import Ideas from './Ideas'

export default function App() {
  const { parts, query } = useRoute()

  if (!isConfigured) {
    return (
      <Layout>
        <ErrorScreen
          title="Falta conectar la base de datos"
          message="Añade VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY (mira el archivo README.md) y vuelve a publicar la web."
        />
      </Layout>
    )
  }

  let page
  const [section, param] = parts
  if (!section) page = <Home />
  else if (section === 'crear') page = <CreateGroup />
  else if (section === 'ideas') page = <Ideas />
  else if (section === 'admin' && param) page = <Admin token={param} isNew={query.get('nuevo') === '1'} />
  else if (section === 'g' && param) page = <Join slug={param} />
  else if (section === 'p' && param) page = <Me code={param} isNew={query.get('nuevo') === '1'} />
  else page = <ErrorScreen title="Página no encontrada" message="Revisa el enlace que te han enviado." />

  return <Layout key={parts.join('/')}>{page}</Layout>
}
