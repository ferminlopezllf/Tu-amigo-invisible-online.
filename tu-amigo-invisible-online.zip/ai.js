import { isDemo, supabaseUrl, supabaseHeaders } from './api'
import { buildGiftPrompt, parseIdeas } from './giftPrompt'

// Pide ideas de regalo a la IA.
// - Web real: función de Supabase "gift-ideas" (la clave de la IA vive en el servidor).
//   · Con `code` (participante tras el sorteo): usa la lista de deseos de su amigo invisible.
//   · Sin `code` (apartado público "Ideas de regalo"): con límite diario por visitante.
// - Vista previa: usa Claude directamente desde la página publicada.
export async function getGiftIdeas({ code, receiver, recipient, profile, traits, priceMin, priceMax, avoid }) {
  const min = priceMin ? Math.round(priceMin) : null
  const max = Math.round(priceMax)

  if (isDemo) {
    const sample = window.claude?.use ? await window.claude.use('sample') : null
    if (!sample) throw new Error('La IA no está disponible en esta vista. Abre la vista previa desde claude.ai.')
    const prompt = buildGiftPrompt({
      receiverName: receiver?.name, recipient, wishlist: receiver?.wishlist, profile, traits, priceMin: min, priceMax: max, avoid,
    })
    try {
      return parseIdeas(await sample.json(prompt, { modelTier: 'quick' }), max, min || 0)
    } catch (e) {
      if (e?.code === 'not_granted') throw new Error('Necesitas dar permiso para usar la IA en esta página.')
      if (e?.code === 'rate_limited') throw new Error('Has pedido muchas ideas seguidas. Espera un momento y vuelve a probar.')
      throw new Error(e?.message || 'No se pudieron generar ideas. Inténtalo otra vez.')
    }
  }

  let res
  try {
    res = await fetch(`${supabaseUrl}/functions/v1/gift-ideas`, {
      method: 'POST',
      headers: supabaseHeaders(),
      body: JSON.stringify({ code: code || null, recipient, profile, traits, priceMin: min, priceMax: max, avoid }),
    })
  } catch {
    throw new Error('No se pudo conectar con el asistente de ideas.')
  }
  const data = await res.json().catch(() => null)
  if (res.status === 404) throw new Error('El asistente de ideas todavía no está activado en esta web (mira el paso 5 del README).')
  if (!res.ok) throw new Error(data?.error || 'No se pudieron generar ideas. Inténtalo otra vez.')
  return parseIdeas(data, max, min || 0)
}
