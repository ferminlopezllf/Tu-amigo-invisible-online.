// Instrucciones para la IA de ideas de regalo.
// (La función del servidor supabase/functions/gift-ideas/index.ts usa una copia de este texto.)

export function buildGiftPrompt({ receiverName, recipient, wishlist = {}, profile, traits = [], priceMin, priceMax, avoid = [] }) {
  const w = wishlist || {}
  const who = receiverName || recipient || 'esta persona'
  const price = priceMin
    ? `- Cada idea debe costar ENTRE ${priceMin} € y ${priceMax} € (precio aproximado realista en España). No propongas nada más barato ni más caro.`
    : `- Cada idea debe costar como MÁXIMO ${priceMax} € (precio aproximado realista en España).`
  const lines = [
    'Eres un asesor de regalos experto para regalos de Navidad y amigo invisible en España.',
    `Propón 6 ideas de regalo concretas y variadas para ${who}.`,
    '',
    'REGLAS:',
    price,
    '- Variedad: mezcla algo práctico, una experiencia o actividad, algo personalizado o hecho con cariño, algo relacionado con sus aficiones y algún detalle original.',
    '- Ideas específicas (no "un libro", sino qué tipo de libro o un ejemplo concreto), que se puedan comprar en tiendas físicas u online habituales en España.',
    '- Respeta lo que NO quiere recibir. No propongas nada inapropiado para un regalo entre amigos, familia o compañeros.',
    '- Escribe en español, en tono cercano y breve.',
    '',
    'LO QUE SABEMOS DE LA PERSONA:',
  ]
  if (recipient?.trim() && receiverName) lines.push(`- Quién es: ${recipient.trim()}`)
  if (recipient?.trim() && !receiverName) lines.push(`- Para quién es el regalo: ${recipient.trim()}`)
  if (profile?.trim()) lines.push(`- Cómo la describe quien le regala: ${profile.trim()}`)
  if (traits.length) lines.push(`- Rasgos: ${traits.join(', ')}`)
  if (w.wants?.trim()) lines.push(`- Le gustaría recibir: ${w.wants.trim()}`)
  if (w.hobbies?.trim()) lines.push(`- Aficiones: ${w.hobbies.trim()}`)
  if (w.dislikes?.trim()) lines.push(`- NO quiere recibir: ${w.dislikes.trim()}`)
  if (w.about?.trim()) lines.push(`- Sobre sus gustos: ${w.about.trim()}`)
  if (!profile?.trim() && !traits.length && !recipient?.trim() && !Object.values(w).some((v) => v?.trim())) {
    lines.push('- No sabemos casi nada: propone ideas universales que gusten a casi todo el mundo.')
  }
  if (avoid.length) lines.push('', `No repitas estas ideas ya propuestas: ${avoid.join('; ')}.`)
  lines.push(
    '',
    'Responde SOLO con JSON válido, sin texto antes ni después, con esta forma exacta:',
    '{"ideas":[{"titulo":"…","descripcion":"una frase con qué es exactamente","precio":25,"por_que":"una frase de por qué encaja con su personalidad","donde":"tipo de tienda o web donde encontrarlo"}]}',
  )
  return lines.join('\n')
}

// Acepta la respuesta de la IA (objeto o texto) y devuelve una lista limpia de ideas
export function parseIdeas(raw, priceMax, priceMin = 0) {
  let data = raw
  if (typeof raw === 'string') {
    const m = raw.match(/\{[\s\S]*\}/)
    try { data = JSON.parse(m ? m[0] : raw) } catch { data = null }
  }
  const list = Array.isArray(data) ? data : data?.ideas
  if (!Array.isArray(list)) throw new Error('La IA no devolvió ideas. Inténtalo otra vez.')
  return list
    .map((i) => ({
      title: String(i.titulo ?? i.title ?? '').trim(),
      description: String(i.descripcion ?? i.description ?? '').trim(),
      price: Number(String(i.precio ?? i.price ?? '').replace(',', '.').replace(/[^\d.]/g, '')) || null,
      why: String(i.por_que ?? i.why ?? '').trim(),
      where: String(i.donde ?? i.where ?? '').trim(),
    }))
    .filter((i) => i.title && (i.price == null || (i.price <= priceMax * 1.05 && i.price >= priceMin * 0.9)))
    .slice(0, 8)
}
