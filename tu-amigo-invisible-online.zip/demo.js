// MODO DEMOSTRACIÓN — solo para la vista previa (VITE_DEMO=1).
// Imita las funciones de supabase/schema.sql dentro del navegador para poder
// probar la web sin servidor. Los datos se quedan en este navegador.
// La web real (sin VITE_DEMO) usa siempre Supabase.

const KEY = 'amigo-invisible:demo-db'
let mem = null
const load = () => {
  if (mem) return mem
  try { mem = JSON.parse(localStorage.getItem(KEY)) } catch { mem = null }
  if (!mem) mem = { groups: [], participants: [], assignments: [] }
  return mem
}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(mem)) } catch { /* sin almacenamiento */ } }
const fail = (m) => { throw new Error(m) }
const wait = () => new Promise((r) => setTimeout(r, 180))
const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
const code = (n) => Array.from(crypto.getRandomValues(new Uint8Array(n)), (b) => ALPHA[b % 32]).join('')
const clean = (s) => String(s ?? '').replace(/\s+/g, ' ').trim()
const norm = (c) => String(c ?? '').replace(/[^A-Za-z0-9]/g, '').toUpperCase()

function pub(g) {
  const db = load()
  return {
    slug: g.slug, name: g.name, budget: g.budget, delivery_date: g.delivery_date,
    admin_can_see_results: g.admin_can_see_results, status: g.status, drawn_at: g.drawn_at,
    participants: db.participants.filter((p) => p.group_id === g.id)
      .map((p) => ({ id: p.id, name: p.name, joined: !!p.access_code, joined_at: p.joined_at })),
  }
}
const byAdmin = (t) => load().groups.find((g) => g.admin_token === t) || fail('Enlace de organizador no válido')
const bySlug = (s) => load().groups.find((g) => g.slug === String(s).toLowerCase()) || fail('Este enlace de invitación no existe')
const byCode = (c) => load().participants.find((p) => p.access_code && p.access_code === norm(c)) || fail('Código personal no válido')
const wl = (p) => ({ wants: p.wish_wants, hobbies: p.wish_hobbies, dislikes: p.wish_dislikes, about: p.wish_about })

function newParticipant(gid, name) {
  return { id: crypto.randomUUID(), group_id: gid, name, access_code: null, joined_at: null, wish_wants: '', wish_hobbies: '', wish_dislikes: '', wish_about: '' }
}

export const demoApi = {
  async createGroup({ name, participants, budget, deliveryDate, adminCanSeeResults }) {
    await wait()
    const db = load()
    const n = clean(name)
    if (!n) fail('Escribe un nombre para el grupo')
    const names = participants.map(clean).filter(Boolean)
    if (names.length < 3) fail('Hacen falta al menos 3 participantes')
    if (names.length > 50) fail('El máximo es de 50 participantes')
    if (new Set(names.map((x) => x.toLowerCase())).size !== names.length) fail('Hay nombres repetidos. Cada participante debe tener un nombre distinto')
    if (!(budget > 0)) fail('El presupuesto debe ser mayor que 0')
    const g = {
      id: crypto.randomUUID(), slug: code(10).toLowerCase(), admin_token: code(14) + code(14) + code(14),
      name: n, budget: Math.round(budget * 100) / 100, delivery_date: deliveryDate || null,
      admin_can_see_results: !!adminCanSeeResults, status: 'open', drawn_at: null,
    }
    db.groups.push(g)
    names.forEach((x) => db.participants.push(newParticipant(g.id, x)))
    save()
    return { slug: g.slug, admin_token: g.admin_token }
  },
  async adminGetGroup(t) { return pub(byAdmin(t)) },
  async adminAddParticipant(t, name) {
    await wait()
    const g = byAdmin(t); const db = load(); const n = clean(name)
    if (g.status !== 'open') fail('El sorteo ya se ha realizado; no se pueden añadir participantes')
    const list = db.participants.filter((p) => p.group_id === g.id)
    if (list.length >= 50) fail('El grupo ya tiene el máximo de 50 participantes')
    if (list.some((p) => p.name.toLowerCase() === n.toLowerCase())) fail(`Ya hay un participante llamado "${n}"`)
    db.participants.push(newParticipant(g.id, n)); save()
    return pub(g)
  },
  async adminRemoveParticipant(t, id) {
    await wait()
    const g = byAdmin(t); const db = load()
    if (g.status !== 'open') fail('El sorteo ya se ha realizado; no se pueden eliminar participantes')
    db.participants = db.participants.filter((p) => !(p.id === id && p.group_id === g.id)); save()
    return pub(g)
  },
  async adminRunDraw(t) {
    await wait()
    const g = byAdmin(t); const db = load()
    if (g.status !== 'open') fail('El sorteo ya se realizó y no se puede repetir')
    const ids = db.participants.filter((p) => p.group_id === g.id).map((p) => p.id)
    if (ids.length < 3) fail('Hacen falta al menos 3 participantes para sortear')
    let perm
    do {
      perm = [...ids]
      for (let i = perm.length - 1; i > 0; i--) {
        const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
        [perm[i], perm[j]] = [perm[j], perm[i]]
      }
    } while (perm.some((x, i) => x === ids[i]))
    ids.forEach((gid, i) => db.assignments.push({ group_id: g.id, giver_id: gid, receiver_id: perm[i] }))
    g.status = 'drawn'; g.drawn_at = new Date().toISOString(); save()
    return pub(g)
  },
  async adminGetResults(t) {
    const g = byAdmin(t); const db = load()
    if (!g.admin_can_see_results) fail('Este grupo se creó con los resultados ocultos también para el organizador')
    if (g.status !== 'drawn') fail('Todavía no se ha realizado el sorteo')
    const name = (id) => db.participants.find((p) => p.id === id).name
    return db.assignments.filter((a) => a.group_id === g.id).map((a) => ({ giver: name(a.giver_id), receiver: name(a.receiver_id) }))
  },
  async getGroupPublic(slug) { return pub(bySlug(slug)) },
  async joinGroup(slug, id) {
    await wait()
    const g = bySlug(slug)
    const p = load().participants.find((x) => x.id === id && x.group_id === g.id) || fail('Ese participante no existe en este grupo')
    if (p.access_code) fail('Esa persona ya se ha unido. Si eres tú, entra con tu enlace o código personal')
    p.access_code = code(12); p.joined_at = new Date().toISOString(); save()
    return { code: p.access_code, name: p.name }
  },
  async getMe(c) {
    const p = byCode(c); const g = load().groups.find((x) => x.id === p.group_id)
    return { me: { id: p.id, name: p.name, code: p.access_code, wishlist: wl(p) }, group: pub(g) }
  },
  async getMyResult(c) {
    const p = byCode(c); const db = load(); const g = db.groups.find((x) => x.id === p.group_id)
    if (g.status !== 'drawn') fail('El sorteo todavía no se ha realizado')
    const a = db.assignments.find((x) => x.giver_id === p.id)
    const r = db.participants.find((x) => x.id === a.receiver_id)
    return { receiver: { name: r.name, wishlist: wl(r) }, budget: g.budget, delivery_date: g.delivery_date, group_name: g.name }
  },
  async updateWishlist(c, w) {
    await wait()
    const p = byCode(c)
    p.wish_wants = clean(w.wants).slice(0, 1000); p.wish_hobbies = clean(w.hobbies).slice(0, 1000)
    p.wish_dislikes = clean(w.dislikes).slice(0, 1000); p.wish_about = clean(w.about).slice(0, 1000)
    save(); return { ok: true }
  },
  // Solo en la demo: simula que el resto de participantes se unen desde sus móviles
  async demoJoinAll(t) {
    const g = byAdmin(t)
    load().participants.filter((p) => p.group_id === g.id && !p.access_code)
      .forEach((p) => { p.access_code = code(12); p.joined_at = new Date().toISOString() })
    save(); return pub(g)
  },
}
