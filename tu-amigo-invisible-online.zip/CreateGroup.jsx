import { useRef, useState } from 'react'
import { Alert, Button, Card, Icon, Label, inputCls } from './ui'
import { api } from './api'
import { navigate } from './router'
import { local, normalizeName } from './utils'

const MAX = 50

export default function CreateGroup() {
  const [groupName, setGroupName] = useState('')
  const [names, setNames] = useState([])
  const [draft, setDraft] = useState('')
  const [nameError, setNameError] = useState('')
  const [budget, setBudget] = useState('50')
  const [date, setDate] = useState('')
  const [adminCanSee, setAdminCanSee] = useState(false)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  const inputRef = useRef(null)

  const exists = (n, list = names) => list.some((x) => x.toLowerCase() === n.toLowerCase())

  // Admite escribir un nombre o pegar varios a la vez (uno por línea o separados por comas)
  const addNames = (raw) => {
    const incoming = raw.split(/[\n,;]+/).map(normalizeName).filter(Boolean)
    if (!incoming.length) return
    const next = [...names]
    const dupes = []
    let tooLong = false
    let full = false
    for (const n of incoming) {
      if (n.length > 60) { tooLong = true; continue }
      if (exists(n, next)) { dupes.push(n); continue }
      if (next.length >= MAX) { full = true; break }
      next.push(n)
    }
    setNames(next)
    setDraft('')
    if (full) setNameError(`Has llegado al máximo de ${MAX} participantes.`)
    else if (dupes.length) setNameError(`"${dupes[0]}" ya está en la lista. Usa nombres distintos (por ejemplo, añade el apellido).`)
    else if (tooLong) setNameError('Algún nombre era demasiado largo (máximo 60 caracteres).')
    else setNameError('')
    inputRef.current?.focus()
  }

  const remove = (n) => { setNames(names.filter((x) => x !== n)); setNameError('') }

  const budgetNum = Number(String(budget).replace(',', '.'))
  const canSubmit = groupName.trim() && names.length >= 3 && budgetNum > 0

  const submit = async (e) => {
    e.preventDefault()
    if (draft.trim()) { addNames(draft); return }
    if (!canSubmit) return
    setSaving(true)
    setError('')
    try {
      const res = await api.createGroup({
        name: groupName.trim(),
        participants: names,
        budget: budgetNum,
        deliveryDate: date || null,
        adminCanSeeResults: adminCanSee,
      })
      local.saveAdmin(res.slug, res.admin_token, groupName.trim())
      navigate(`/admin/${res.admin_token}?nuevo=1`)
    } catch (err) {
      setError(err.message)
      setSaving(false)
    }
  }

  const pct = Math.round((names.length / MAX) * 100)

  return (
    <div className="mx-auto max-w-2xl">
      <a href="#/" className="mb-5 inline-flex items-center gap-2 text-sm font-medium text-white/60 hover:text-white">
        <Icon.Back className="h-4 w-4" /> Volver
      </a>
      <h1 className="font-display text-4xl font-semibold text-white animate-fade-up sm:text-5xl">Crea tu grupo</h1>
      <p className="mt-2 text-white/60 animate-fade-up">Solo te llevará un minuto. Después podrás compartirlo por WhatsApp.</p>

      <form onSubmit={submit} className="mt-8 space-y-5">
        {/* Nombre */}
        <Card className="p-6 animate-fade-up sm:p-7">
          <Label htmlFor="gname">Nombre del grupo</Label>
          <input
            id="gname"
            value={groupName}
            onChange={(e) => setGroupName(e.target.value)}
            maxLength={80}
            placeholder="Ej.: Navidad familia García 2026"
            className={inputCls}
          />
        </Card>

        {/* Participantes */}
        <Card className="p-6 animate-fade-up [animation-delay:60ms] sm:p-7">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-white/90">Participantes</h2>
            <span className={`rounded-full px-3 py-1 text-sm font-bold tabular-nums ${names.length >= MAX ? 'bg-berry-500/15 text-berry-400' : 'bg-pine-500/15 text-pine-400'}`}>
              {names.length}/{MAX}
            </span>
          </div>
          <div className="mb-4 h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-gradient-to-r from-pine-600 to-gold-400 transition-all duration-500" style={{ width: `${pct}%` }} />
          </div>

          <div className="flex gap-2">
            <input
              ref={inputRef}
              value={draft}
              onChange={(e) => { setDraft(e.target.value); setNameError('') }}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addNames(draft) } }}
              onPaste={(e) => {
                const t = e.clipboardData.getData('text')
                if (/[\n,;]/.test(t)) { e.preventDefault(); addNames(t) }
              }}
              placeholder="Nombre y apellido"
              aria-label="Nombre del participante"
              disabled={names.length >= MAX}
              className={inputCls}
            />
            <Button type="button" variant="dark" onClick={() => addNames(draft)} disabled={!draft.trim() || names.length >= MAX} aria-label="Añadir participante">
              <Icon.Plus className="h-5 w-5" /> <span className="hidden sm:inline">Añadir</span>
            </Button>
          </div>
          <p className="mt-2 text-xs text-white/50">Consejo: puedes pegar una lista entera (un nombre por línea o separados por comas).</p>
          {nameError && <Alert className="mt-3">{nameError}</Alert>}

          {names.length > 0 ? (
            <ul className="mt-4 flex flex-wrap gap-2">
              {names.map((n) => (
                <li key={n} className="group inline-flex items-center gap-1 rounded-full bg-ink-800 py-1.5 pr-1.5 pl-3.5 text-sm font-medium text-white/90 ring-1 ring-white/10 animate-pop">
                  {n}
                  <button type="button" onClick={() => remove(n)} aria-label={`Eliminar a ${n}`} className="grid h-6 w-6 place-items-center rounded-full text-white/40 transition hover:bg-berry-500/15 hover:text-berry-400">
                    <Icon.X className="h-3.5 w-3.5" />
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-4 rounded-2xl border border-dashed border-white/15 px-4 py-6 text-center text-sm text-white/45">Aún no hay nadie. Añade al menos 3 personas (incluido tú si participas).</p>
          )}
          {names.length > 0 && names.length < 3 && <p className="mt-3 text-xs font-medium text-berry-400">Faltan {3 - names.length} para poder crear el grupo.</p>}
        </Card>

        {/* Presupuesto y fecha */}
        <Card className="grid gap-5 p-6 animate-fade-up [animation-delay:120ms] sm:grid-cols-2 sm:p-7">
          <div>
            <Label htmlFor="budget">Presupuesto máximo</Label>
            <div className="relative">
              <input id="budget" inputMode="decimal" value={budget} onChange={(e) => setBudget(e.target.value.replace(/[^0-9.,]/g, ''))} className={`${inputCls} pr-10`} />
              <span className="pointer-events-none absolute top-1/2 right-4 -translate-y-1/2 font-semibold text-white/40">€</span>
            </div>
          </div>
          <div>
            <Label htmlFor="date" hint="Opcional">Fecha de entrega</Label>
            <input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputCls} />
          </div>
        </Card>

        {/* Privacidad */}
        <Card className="p-6 animate-fade-up [animation-delay:180ms] sm:p-7">
          <label className="flex cursor-pointer items-start gap-4">
            <span className="relative mt-0.5 inline-flex shrink-0">
              <input type="checkbox" className="peer sr-only" checked={adminCanSee} onChange={(e) => setAdminCanSee(e.target.checked)} />
              <span className="h-7 w-12 rounded-full bg-white/15 transition peer-checked:bg-pine-600 peer-focus-visible:ring-4 peer-focus-visible:ring-pine-600/20" />
              <span className="absolute top-1 left-1 h-5 w-5 rounded-full bg-white shadow transition peer-checked:translate-x-5" />
            </span>
            <span>
              <span className="block font-semibold text-white/90">Permitir que el organizador vea todos los resultados</span>
              <span className="mt-1 block text-sm text-white/60">
                Desactivado por defecto: ni siquiera tú sabrás quién regala a quién. Actívalo solo si alguien no tiene móvil y necesitas decírselo tú. Todos los participantes verán que esta opción está activa, y no se puede cambiar después.
              </span>
            </span>
          </label>
        </Card>

        {error && <Alert>{error}</Alert>}

        <Button type="submit" size="xl" className="w-full" loading={saving} disabled={!canSubmit}>
          Crear grupo y obtener enlace <Icon.Arrow className="h-5 w-5" />
        </Button>
      </form>
    </div>
  )
}
