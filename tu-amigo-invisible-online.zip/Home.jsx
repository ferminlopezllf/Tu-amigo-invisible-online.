import { useState } from 'react'
import { Button, Card, Icon, Badge, inputCls, WhatsAppIcon } from './ui'
import { navigate } from './router'
import { local } from './utils'
import { Sparkle } from './GiftIdeas'

const steps = [
  { icon: Icon.Users, title: 'Crea el grupo', text: 'Añade hasta 50 participantes, el presupuesto y la fecha de entrega.' },
  { icon: WhatsAppIcon, title: 'Compártelo por WhatsApp', text: 'Cada persona entra desde su móvil y elige su nombre. Sin cuentas ni contraseñas.' },
  { icon: Icon.Lock, title: 'Sorteo 100% privado', text: 'El sorteo se hace en el servidor. Cada uno ve solo a quién le toca regalar.' },
]

export default function Home() {
  const [code, setCode] = useState('')
  const saved = local.all()
  const adminGroups = Object.entries(saved.admin)
  const memberGroups = Object.entries(saved.member)

  const goCode = (e) => {
    e.preventDefault()
    const clean = code.replace(/[^A-Za-z0-9]/g, '').toUpperCase()
    if (clean.length >= 8) navigate(`/p/${clean}`)
  }

  return (
    <div className="space-y-16 sm:space-y-24">
      {/* Hero */}
      <section className="mx-auto max-w-3xl pt-6 text-center sm:pt-12">
        <div className="animate-fade-up">
          <Badge tone="white"><Icon.Star className="h-3.5 w-3.5 text-gold-400" /> Gratis · Hasta 50 personas · Sin reuniros</Badge>
        </div>
        <h1 className="mt-6 font-display text-[2.6rem] leading-[1.05] font-semibold tracking-tight text-white animate-fade-up [animation-delay:80ms] sm:text-7xl">
          Organiza tu amigo invisible <span className="italic text-gold-400">en segundos</span>
        </h1>
        <p className="mx-auto mt-5 max-w-xl text-base text-white/70 animate-fade-up [animation-delay:160ms] sm:text-lg">
          Crea el grupo, comparte el enlace por WhatsApp y que cada uno descubra desde su móvil a quién le toca regalar. Nadie más lo sabrá.
        </p>
        <div className="mt-9 flex flex-col items-center gap-4 animate-fade-up [animation-delay:240ms]">
          <Button size="xl" onClick={() => navigate('/crear')} className="w-full max-w-sm sm:w-auto">
            <Icon.Gift className="h-6 w-6" /> Crear un amigo invisible
          </Button>
          <button onClick={() => navigate('/ideas')} className="inline-flex items-center gap-2 text-sm font-semibold text-gold-300 transition hover:text-gold-100">
            <Sparkle className="h-4 w-4" /> ¿Buscas qué regalar? Pide ideas a la IA <Icon.Arrow className="h-4 w-4" />
          </button>
        </div>
      </section>

      {/* Mis grupos en este dispositivo */}
      {(adminGroups.length > 0 || memberGroups.length > 0) && (
        <section className="mx-auto max-w-2xl animate-fade-up">
          <h2 className="mb-3 text-sm font-semibold tracking-wide text-white/50 uppercase">En este dispositivo</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {adminGroups.map(([slug, g]) => (
              <a key={`a-${slug}`} href={`#/admin/${g.token}`} className="group flex items-center justify-between rounded-2xl bg-white/[0.06] px-5 py-4 ring-1 ring-white/10 transition hover:bg-white/10">
                <div>
                  <p className="font-semibold text-white">{g.name}</p>
                  <p className="text-xs text-gold-300">Organizador</p>
                </div>
                <Icon.Arrow className="h-5 w-5 text-white/40 transition group-hover:translate-x-1 group-hover:text-white" />
              </a>
            ))}
            {memberGroups.map(([slug, m]) => (
              <a key={`m-${slug}`} href={`#/p/${m.code}`} className="group flex items-center justify-between rounded-2xl bg-white/[0.06] px-5 py-4 ring-1 ring-white/10 transition hover:bg-white/10">
                <div>
                  <p className="font-semibold text-white">{m.groupName}</p>
                  <p className="text-xs text-white/60">Participas como {m.name}</p>
                </div>
                <Icon.Arrow className="h-5 w-5 text-white/40 transition group-hover:translate-x-1 group-hover:text-white" />
              </a>
            ))}
          </div>
        </section>
      )}

      {/* Cómo funciona */}
      <section>
        <h2 className="text-center font-display text-3xl font-semibold text-white sm:text-4xl">Así de fácil</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {steps.map((s, i) => (
            <div key={s.title} className="rounded-3xl bg-white/[0.06] p-6 ring-1 ring-white/10 backdrop-blur animate-fade-up" style={{ animationDelay: `${i * 90}ms` }}>
              <div className="mb-4 flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gold-400/15 text-gold-400">
                  <s.icon className="h-5 w-5" />
                </span>
                <span className="font-display text-3xl text-white/15">0{i + 1}</span>
              </div>
              <h3 className="text-lg font-semibold text-white">{s.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-white/60">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Ideas de regalo */}
      <section className="mx-auto max-w-3xl">
        <a href="#/ideas" className="group block overflow-hidden rounded-3xl bg-gradient-to-br from-gold-400/[0.12] via-ink-850 to-ink-850 p-6 ring-1 ring-gold-400/20 transition hover:ring-gold-400/40 sm:p-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-4">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-gold-400/15 text-gold-300"><Sparkle className="h-6 w-6" /></span>
              <div>
                <h2 className="font-display text-2xl font-semibold text-white">Ideas de regalo con IA</h2>
                <p className="mt-1 text-sm text-white/60">Describe su personalidad, elige un precio máximo o un intervalo y recibe ideas a su medida. Gratis y sin registrarte.</p>
              </div>
            </div>
            <span className="inline-flex h-12 shrink-0 items-center justify-center gap-2 rounded-2xl bg-gold-400 px-5 font-semibold text-ink-950 transition group-hover:bg-gold-300">
              Buscar ideas <Icon.Arrow className="h-4 w-4" />
            </span>
          </div>
        </a>
      </section>

      {/* Entrar con código */}
      <section className="mx-auto max-w-xl">
        <Card className="p-6 sm:p-8">
          <div className="flex items-start gap-4">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-pine-500/15 text-pine-400"><Icon.Key className="h-5 w-5" /></span>
            <div>
              <h2 className="font-display text-xl font-semibold">¿Ya participas en un grupo?</h2>
              <p className="mt-1 text-sm text-white/60">Escribe tu código personal para ver tu resultado desde cualquier dispositivo.</p>
            </div>
          </div>
          <form onSubmit={goCode} className="mt-5 flex flex-col gap-3 sm:flex-row">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="XXXX-XXXX-XXXX"
              aria-label="Código personal"
              autoCapitalize="characters"
              autoComplete="off"
              className={`${inputCls} font-mono tracking-widest uppercase`}
            />
            <Button variant="dark" type="submit" disabled={code.replace(/[^A-Za-z0-9]/g, '').length < 8}>Entrar</Button>
          </form>
        </Card>
      </section>
    </div>
  )
}
