import { useState } from 'react'
import { Alert, Button, Card, Icon, Label, inputCls } from './ui'
import { getGiftIdeas } from './ai'
import { formatMoney } from './utils'

const TRAITS = [
  'Deportista', 'Cocinillas', 'Lector/a', 'Gamer', 'Viajero/a', 'Tecnológico/a', 'Creativo/a', 'Casero/a',
  'Fiestero/a', 'Elegante', 'Melómano/a', 'Cinéfilo/a', 'Amante de la naturaleza', 'Tiene mascotas', 'Bromista', 'Práctico/a',
]
const SLIDER_MIN = 5
const GAP = 5 // diferencia mínima entre el mínimo y el máximo del intervalo

export const Sparkle = (p) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...p}>
    <path d="M12 2l1.8 5.4L19 9.2l-5.2 1.8L12 16.4l-1.8-5.4L5 9.2l5.2-1.8L12 2zm7 11l.9 2.6 2.6.9-2.6.9L19 20l-.9-2.6-2.6-.9 2.6-.9L19 13zM5 14l.7 1.8 1.8.7-1.8.7L5 19l-.7-1.8-1.8-.7 1.8-.7L5 14z" />
  </svg>
)

// ---------- Selector de precio: "Hasta" o "Entre" ----------
function PriceControl({ mode, setMode, min, setMin, max, setMax, sliderMax, reference }) {
  const pct = (v) => ((v - SLIDER_MIN) / (sliderMax - SLIDER_MIN)) * 100
  const step = sliderMax > 200 ? 5 : 1
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <span className="text-sm font-semibold text-white/90">Precio</span>
        <div className="inline-flex rounded-full bg-ink-800 p-1 ring-1 ring-white/10" role="radiogroup" aria-label="Tipo de precio">
          {[['max', 'Precio máximo'], ['range', 'Intervalo']].map(([k, label]) => (
            <button
              key={k}
              type="button"
              role="radio"
              aria-checked={mode === k}
              onClick={() => { setMode(k); if (k === 'range' && min > max - GAP) setMin(Math.max(SLIDER_MIN, max - 20)) }}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold transition ${mode === k ? 'bg-gold-400 text-ink-950' : 'text-white/60 hover:text-white'}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <p className="mb-3 text-center text-2xl font-bold tabular-nums text-gold-300" aria-live="polite">
        {mode === 'max' ? <>Hasta {formatMoney(max)}</> : <>Entre {formatMoney(min)} y {formatMoney(max)}</>}
      </p>

      {mode === 'max' ? (
        <input
          id="ai-budget"
          type="range"
          min={SLIDER_MIN}
          max={sliderMax}
          step={step}
          value={max}
          onChange={(e) => setMax(Number(e.target.value))}
          aria-label="Precio máximo"
          className="budget-range w-full"
          style={{ '--from': '0%', '--to': `${pct(max)}%` }}
        />
      ) : (
        <div className="dual-range" style={{ '--from': `${pct(min)}%`, '--to': `${pct(max)}%` }}>
          <div className="dual-track" />
          <input
            id="ai-min"
            type="range"
            min={SLIDER_MIN}
            max={sliderMax}
            step={step}
            value={min}
            onChange={(e) => setMin(Math.min(Number(e.target.value), max - GAP))}
            aria-label="Precio mínimo"
          />
          <input
            id="ai-max"
            type="range"
            min={SLIDER_MIN}
            max={sliderMax}
            step={step}
            value={max}
            onChange={(e) => setMax(Math.max(Number(e.target.value), min + GAP))}
            aria-label="Precio máximo"
          />
        </div>
      )}

      <div className="mt-1.5 flex justify-between text-xs text-white/40">
        <span>{SLIDER_MIN} €</span>
        {reference && <span>{reference.label}: {formatMoney(reference.value)}</span>}
        <span>{sliderMax} €</span>
      </div>
      {reference && max > reference.value && (
        <p className="mt-2 text-xs font-medium text-gold-300">Ojo: estás por encima del presupuesto acordado en el grupo.</p>
      )}
    </div>
  )
}

// ---------- Asistente ----------
// Con `result` (tras el sorteo) usa los datos de tu amigo invisible.
// Sin `result` es el apartado público: cualquiera describe a la persona.
export default function GiftIdeas({ code, result, bare = false }) {
  const groupBudget = result ? Number(result.budget) : null
  const first = result ? result.receiver.name.split(' ')[0] : null
  const sliderMax = groupBudget ? Math.max(100, Math.ceil((groupBudget * 2) / 10) * 10) : 300

  const [recipient, setRecipient] = useState('')
  const [profile, setProfile] = useState('')
  const [traits, setTraits] = useState([])
  const [mode, setMode] = useState('max')
  const [max, setMax] = useState(groupBudget ? Math.min(Math.round(groupBudget), sliderMax) : 50)
  const [min, setMin] = useState(groupBudget ? Math.max(SLIDER_MIN, Math.round(groupBudget * 0.6)) : 20)
  const [ideas, setIdeas] = useState([])
  const [seen, setSeen] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const toggle = (t) => setTraits((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]))
  const name = first || (recipient.trim() ? recipient.trim() : 'esa persona')

  const generate = async (more = false) => {
    setLoading(true); setError('')
    try {
      const list = await getGiftIdeas({
        code: result ? code : null,
        receiver: result?.receiver,
        recipient,
        profile,
        traits,
        priceMin: mode === 'range' ? min : null,
        priceMax: max,
        avoid: more ? seen : [],
      })
      if (!list.length) throw new Error('No han salido ideas en ese rango de precio. Prueba a ampliarlo un poco.')
      setIdeas(list)
      setSeen((s) => (more ? [...s, ...list.map((i) => i.title)] : list.map((i) => i.title)))
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  const body = (
    <div className="space-y-6 p-6 sm:p-8">
      {!result && (
        <div>
          <Label htmlFor="ai-recipient" hint="Opcional">¿Para quién es el regalo?</Label>
          <input
            id="ai-recipient"
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            maxLength={80}
            placeholder="Ej.: mi suegra, un compañero de trabajo, mi hermano de 16 años…"
            className={inputCls}
          />
        </div>
      )}

      <div>
        <Label htmlFor="ai-profile" hint="Cuanto más cuentes, mejor">{first ? `¿Cómo es ${first}?` : '¿Cómo es su personalidad?'}</Label>
        <textarea
          id="ai-profile"
          rows={3}
          maxLength={1500}
          value={profile}
          onChange={(e) => setProfile(e.target.value)}
          placeholder="Ej.: es muy ordenado/a, le encanta el café y el senderismo, siempre tiene frío y acaba de mudarse a un piso nuevo…"
          className={`${inputCls} resize-y`}
        />
      </div>

      <div>
        <p className="mb-2 text-sm font-semibold text-white/90">Personalidad y gustos <span className="font-medium text-white/40">· toca los que encajen</span></p>
        <div className="flex flex-wrap gap-2">
          {TRAITS.map((t) => {
            const on = traits.includes(t)
            return (
              <button
                key={t}
                type="button"
                onClick={() => toggle(t)}
                aria-pressed={on}
                className={`rounded-full px-3.5 py-1.5 text-sm font-medium transition ${on
                  ? 'bg-gold-400 text-ink-950 shadow-md shadow-gold-500/20'
                  : 'bg-ink-800 text-white/70 ring-1 ring-white/10 hover:text-white hover:ring-white/25'}`}
              >
                {t}
              </button>
            )
          })}
        </div>
      </div>

      <PriceControl
        mode={mode} setMode={setMode} min={min} setMin={setMin} max={max} setMax={setMax}
        sliderMax={sliderMax}
        reference={groupBudget ? { label: 'Presupuesto del grupo', value: groupBudget } : null}
      />

      {error && <Alert>{error}</Alert>}

      <Button size="lg" variant="gold" className="w-full" onClick={() => generate(false)} loading={loading && !ideas.length}>
        <Sparkle className="h-5 w-5" /> {ideas.length ? 'Generar ideas nuevas' : 'Darme ideas de regalo'}
      </Button>

      {loading && (
        <div className="space-y-3" aria-live="polite">
          <p className="text-center text-sm text-white/50">Pensando ideas para {name}…</p>
          <div className="grid gap-3 sm:grid-cols-2">
            {[0, 1, 2, 3].map((i) => <div key={i} className="h-36 animate-pulse rounded-2xl bg-ink-800" />)}
          </div>
        </div>
      )}

      {!loading && ideas.length > 0 && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2">
            {ideas.map((idea, i) => (
              <article key={idea.title + i} className="flex flex-col rounded-2xl bg-ink-800 p-5 ring-1 ring-white/[0.07] animate-fade-up" style={{ animationDelay: `${i * 60}ms` }}>
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-semibold leading-snug text-white">{idea.title}</h3>
                  {idea.price != null && (
                    <span className="shrink-0 rounded-full bg-gold-400/15 px-2.5 py-1 text-xs font-bold text-gold-300">~{formatMoney(idea.price)}</span>
                  )}
                </div>
                {idea.description && <p className="mt-2 text-sm text-white/70">{idea.description}</p>}
                {idea.why && <p className="mt-3 flex gap-2 text-sm text-white/55"><Icon.Heart className="mt-0.5 h-3.5 w-3.5 shrink-0 text-berry-400" />{idea.why}</p>}
                {idea.where && <p className="mt-auto flex gap-2 pt-3 text-xs text-white/40"><Icon.Gift className="h-3.5 w-3.5 shrink-0" />{idea.where}</p>}
              </article>
            ))}
          </div>
          <Button variant="outline" className="w-full" onClick={() => generate(true)}>
            <Icon.Refresh className="h-4 w-4" /> Dame otras ideas distintas
          </Button>
          <p className="text-center text-xs text-white/35">Precios aproximados. Las ideas las genera una IA: revisa disponibilidad y precio antes de comprar.</p>
        </div>
      )}
    </div>
  )

  if (bare) return <Card className="overflow-hidden p-0">{body}</Card>

  return (
    <Card className="overflow-hidden p-0 animate-fade-up">
      <div className="border-b border-white/[0.06] bg-gradient-to-br from-gold-400/[0.08] to-transparent p-6 sm:p-8">
        <div className="flex items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gold-400/15 text-gold-300"><Sparkle className="h-5 w-5" /></span>
          <div>
            <h2 className="font-display text-xl font-semibold">¿No sabes qué regalarle a {first}?</h2>
            <p className="mt-1 text-sm text-white/60">Cuéntale a la IA cómo es, elige el precio y te propondrá ideas a su medida.</p>
          </div>
        </div>
      </div>
      {body}
    </Card>
  )
}
