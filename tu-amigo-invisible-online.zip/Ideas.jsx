import GiftIdeas, { Sparkle } from './GiftIdeas'
import { Icon } from './ui'

// Apartado público: ideas de regalo con IA para cualquier persona, sin grupo ni sorteo
export default function Ideas() {
  return (
    <div className="mx-auto max-w-2xl">
      <a href="#/" className="mb-5 inline-flex items-center gap-2 text-sm font-medium text-white/60 hover:text-white">
        <Icon.Back className="h-4 w-4" /> Volver
      </a>
      <div className="animate-fade-up">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-gold-400/10 px-3 py-1 text-xs font-semibold text-gold-300 ring-1 ring-gold-400/20">
          <Sparkle className="h-3.5 w-3.5" /> Con inteligencia artificial
        </span>
        <h1 className="mt-4 font-display text-4xl font-semibold text-white sm:text-5xl">Ideas de regalo</h1>
        <p className="mt-2 text-white/60">Describe a la persona, elige cuánto quieres gastar —un máximo o un intervalo— y te damos ideas que encajen con ella.</p>
      </div>
      <div className="mt-8 animate-fade-up [animation-delay:80ms]">
        <GiftIdeas bare />
      </div>
    </div>
  )
}
