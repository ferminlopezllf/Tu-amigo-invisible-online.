-- =====================================================================
--  AMIGO INVISIBLE ONLINE — Base de datos, seguridad y sorteo
--  Pega este archivo completo en Supabase > SQL Editor > Run.
--  Se puede ejecutar varias veces sin problema (es idempotente).
-- =====================================================================
--
--  Modelo de seguridad
--  -------------------
--  * Las tablas tienen RLS activado y NINGUNA política: desde el navegador
--    nadie puede leer ni escribir directamente en ellas.
--  * Todo pasa por funciones (RPC) "security definer" que comprueban el
--    código privado de quien llama y solo devuelven lo que esa persona
--    tiene derecho a ver.
--  * El organizador se identifica con un token de administración secreto.
--  * Cada participante se identifica con su código personal (12 caracteres
--    aleatorios ≈ 60 bits), que se genera cuando reclama su nombre.
--  * El sorteo se hace dentro de la base de datos, bloqueando el grupo
--    para que no pueda repetirse ni ejecutarse dos veces a la vez.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Tablas
-- ---------------------------------------------------------------------
create table if not exists public.groups (
  id                    uuid primary key default gen_random_uuid(),
  slug                  text not null unique,
  admin_token           text not null unique,
  name                  text not null check (char_length(name) between 1 and 80),
  budget                numeric(10,2) not null default 50 check (budget > 0 and budget <= 100000),
  delivery_date         date,
  admin_can_see_results boolean not null default false,
  status                text not null default 'open' check (status in ('open', 'drawn')),
  drawn_at              timestamptz,
  created_at            timestamptz not null default now()
);

create table if not exists public.participants (
  id            uuid primary key default gen_random_uuid(),
  group_id      uuid not null references public.groups(id) on delete cascade,
  name          text not null check (char_length(name) between 1 and 60),
  access_code   text unique,              -- null hasta que la persona reclama su nombre
  joined_at     timestamptz,
  wish_wants    text not null default '' check (char_length(wish_wants)    <= 1000),
  wish_hobbies  text not null default '' check (char_length(wish_hobbies)  <= 1000),
  wish_dislikes text not null default '' check (char_length(wish_dislikes) <= 1000),
  wish_about    text not null default '' check (char_length(wish_about)    <= 1000),
  created_at    timestamptz not null default clock_timestamp()
);

-- Nombres únicos dentro de un grupo (sin distinguir mayúsculas ni espacios extra)
create unique index if not exists participants_unique_name
  on public.participants (group_id, lower(btrim(name)));
create index if not exists participants_group_idx on public.participants (group_id);

create table if not exists public.assignments (
  group_id    uuid not null references public.groups(id) on delete cascade,
  giver_id    uuid primary key references public.participants(id) on delete cascade,
  receiver_id uuid not null unique references public.participants(id) on delete cascade,
  check (giver_id <> receiver_id)        -- nadie se regala a sí mismo
);
-- giver_id es PK  → cada persona regala exactamente una vez
-- receiver_id es UNIQUE → nadie recibe dos regalos

-- ---------------------------------------------------------------------
-- Bloqueo total del acceso directo a las tablas
-- ---------------------------------------------------------------------
alter table public.groups       enable row level security;
alter table public.participants enable row level security;
alter table public.assignments  enable row level security;

revoke all on public.groups, public.participants, public.assignments from public;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    execute 'revoke all on public.groups, public.participants, public.assignments from anon';
  end if;
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on public.groups, public.participants, public.assignments from authenticated';
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Utilidades internas
-- ---------------------------------------------------------------------

-- Código aleatorio criptográficamente seguro (alfabeto sin 0/O/1/I)
create or replace function public._random_code(p_len int)
returns text
language plpgsql
volatile
set search_path = public
as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- 32 símbolos
  -- bytes de un UUID v4 que son 100% aleatorios (se excluyen 6 y 8: versión/variante)
  usable   constant int[] := array[0,1,2,3,4,5,7,9,10,11,12,13,14,15];
  b        bytea;
  result   text := '';
  i        int;
begin
  if p_len < 1 or p_len > 14 then
    raise exception 'longitud de código no válida';
  end if;
  b := uuid_send(gen_random_uuid());
  for i in 1..p_len loop
    -- 256 es múltiplo de 32 → distribución uniforme
    result := result || substr(alphabet, (get_byte(b, usable[i]) % 32) + 1, 1);
  end loop;
  return result;
end;
$$;

create or replace function public._normalize_code(p_code text)
returns text
language sql
immutable
as $$
  select upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
$$;

create or replace function public._clean_name(p_name text)
returns text
language sql
immutable
as $$
  select btrim(regexp_replace(coalesce(p_name, ''), '\s+', ' ', 'g'));
$$;

create or replace function public._group_by_admin(p_admin_token text)
returns public.groups
language plpgsql
stable
security definer
set search_path = public
as $$
declare g public.groups;
begin
  select * into g from public.groups where admin_token = coalesce(p_admin_token, '');
  if not found then
    raise exception 'Enlace de organizador no válido';
  end if;
  return g;
end;
$$;

create or replace function public._participants_summary(p_group_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', p.id,
           'name', p.name,
           'joined', p.access_code is not null,
           'joined_at', p.joined_at
         ) order by p.created_at), '[]'::jsonb)
  from public.participants p
  where p.group_id = p_group_id;
$$;

create or replace function public._group_public(g public.groups)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'slug', g.slug,
    'name', g.name,
    'budget', g.budget,
    'delivery_date', g.delivery_date,
    'admin_can_see_results', g.admin_can_see_results,
    'status', g.status,
    'drawn_at', g.drawn_at,
    'participants', public._participants_summary(g.id)
  );
$$;

-- ---------------------------------------------------------------------
-- RPC: crear grupo
-- ---------------------------------------------------------------------
create or replace function public.create_group(
  p_name text,
  p_participants text[],
  p_budget numeric default 50,
  p_delivery_date date default null,
  p_admin_can_see_results boolean default false
)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  v_name   text := public._clean_name(p_name);
  v_names  text[];
  v_group  public.groups;
  v_n      text;
  v_slug   text;
  v_admin  text;
begin
  if char_length(v_name) = 0 then
    raise exception 'Escribe un nombre para el grupo';
  end if;
  if char_length(v_name) > 80 then
    raise exception 'El nombre del grupo es demasiado largo (máximo 80 caracteres)';
  end if;

  select coalesce(array_agg(public._clean_name(x)), '{}')
    into v_names
    from unnest(coalesce(p_participants, '{}')) x
   where public._clean_name(x) <> '';

  if cardinality(v_names) < 3 then
    raise exception 'Hacen falta al menos 3 participantes';
  end if;
  if cardinality(v_names) > 50 then
    raise exception 'El máximo es de 50 participantes';
  end if;
  if (select count(distinct lower(n)) from unnest(v_names) n) <> cardinality(v_names) then
    raise exception 'Hay nombres repetidos. Cada participante debe tener un nombre distinto';
  end if;
  foreach v_n in array v_names loop
    if char_length(v_n) > 60 then
      raise exception 'El nombre "%" es demasiado largo (máximo 60 caracteres)', left(v_n, 20) || '…';
    end if;
  end loop;

  if p_budget is null or p_budget <= 0 or p_budget > 100000 then
    raise exception 'El presupuesto debe ser mayor que 0';
  end if;

  -- slug único para el enlace de invitación
  loop
    v_slug := lower(public._random_code(10));
    exit when not exists (select 1 from public.groups where slug = v_slug);
  end loop;
  v_admin := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');

  insert into public.groups (slug, admin_token, name, budget, delivery_date, admin_can_see_results)
  values (v_slug, v_admin, v_name, round(p_budget, 2), p_delivery_date, coalesce(p_admin_can_see_results, false))
  returning * into v_group;

  insert into public.participants (group_id, name)
  select v_group.id, n from unnest(v_names) with ordinality as t(n, ord) order by ord;

  return jsonb_build_object('slug', v_group.slug, 'admin_token', v_group.admin_token);
end;
$$;

-- ---------------------------------------------------------------------
-- RPC: organizador
-- ---------------------------------------------------------------------
create or replace function public.admin_get_group(p_admin_token text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare g public.groups := public._group_by_admin(p_admin_token);
begin
  return public._group_public(g);
end;
$$;

create or replace function public.admin_add_participant(p_admin_token text, p_name text)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  g public.groups := public._group_by_admin(p_admin_token);
  v_name text := public._clean_name(p_name);
begin
  perform 1 from public.groups where id = g.id for update;
  select * into g from public.groups where id = g.id;
  if g.status <> 'open' then
    raise exception 'El sorteo ya se ha realizado; no se pueden añadir participantes';
  end if;
  if char_length(v_name) = 0 or char_length(v_name) > 60 then
    raise exception 'Escribe un nombre válido (máximo 60 caracteres)';
  end if;
  if (select count(*) from public.participants where group_id = g.id) >= 50 then
    raise exception 'El grupo ya tiene el máximo de 50 participantes';
  end if;
  if exists (select 1 from public.participants
              where group_id = g.id and lower(btrim(name)) = lower(v_name)) then
    raise exception 'Ya hay un participante llamado "%"', v_name;
  end if;
  insert into public.participants (group_id, name) values (g.id, v_name);
  return public._group_public(g);
end;
$$;

create or replace function public.admin_remove_participant(p_admin_token text, p_participant_id uuid)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare g public.groups := public._group_by_admin(p_admin_token);
begin
  perform 1 from public.groups where id = g.id for update;
  select * into g from public.groups where id = g.id;
  if g.status <> 'open' then
    raise exception 'El sorteo ya se ha realizado; no se pueden eliminar participantes';
  end if;
  delete from public.participants where id = p_participant_id and group_id = g.id;
  if not found then
    raise exception 'Ese participante no existe en este grupo';
  end if;
  return public._group_public(g);
end;
$$;

-- El sorteo: se hace en el servidor, una única vez, de forma aleatoria y uniforme
create or replace function public.admin_run_draw(p_admin_token text)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  g      public.groups := public._group_by_admin(p_admin_token);
  ids    uuid[];
  perm   uuid[];
  n      int;
  i      int;
  ok     boolean;
  tries  int := 0;
begin
  -- Bloquea el grupo: si dos peticiones llegan a la vez, la segunda espera
  -- y después ve status = 'drawn', así que el sorteo nunca se repite.
  select * into g from public.groups where id = g.id for update;
  if g.status <> 'open' then
    raise exception 'El sorteo ya se realizó y no se puede repetir';
  end if;

  select array_agg(id order by created_at) into ids
    from public.participants where group_id = g.id;
  n := coalesce(cardinality(ids), 0);
  if n < 3 then
    raise exception 'Hacen falta al menos 3 participantes para sortear';
  end if;

  -- Desarreglo aleatorio uniforme: barajamos hasta que nadie se tenga a sí mismo
  -- (de media hacen falta ~2,7 intentos).
  loop
    tries := tries + 1;
    select array_agg(x order by gen_random_uuid()) into perm from unnest(ids) as x;
    ok := true;
    for i in 1..n loop
      if perm[i] = ids[i] then ok := false; exit; end if;
    end loop;
    exit when ok;
    if tries > 10000 then
      raise exception 'No se pudo completar el sorteo, inténtalo de nuevo';
    end if;
  end loop;

  insert into public.assignments (group_id, giver_id, receiver_id)
  select g.id, ids[k], perm[k] from generate_series(1, n) as k;

  update public.groups set status = 'drawn', drawn_at = now() where id = g.id
  returning * into g;

  return public._group_public(g);
end;
$$;

-- Solo funciona si el grupo se creó con "el organizador puede ver los resultados"
create or replace function public.admin_get_results(p_admin_token text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare g public.groups := public._group_by_admin(p_admin_token);
begin
  if not g.admin_can_see_results then
    raise exception 'Este grupo se creó con los resultados ocultos también para el organizador';
  end if;
  if g.status <> 'drawn' then
    raise exception 'Todavía no se ha realizado el sorteo';
  end if;
  return (
    select coalesce(jsonb_agg(jsonb_build_object('giver', pg.name, 'receiver', pr.name)
                              order by pg.created_at), '[]'::jsonb)
      from public.assignments a
      join public.participants pg on pg.id = a.giver_id
      join public.participants pr on pr.id = a.receiver_id
     where a.group_id = g.id
  );
end;
$$;

-- ---------------------------------------------------------------------
-- RPC: participantes
-- ---------------------------------------------------------------------

-- Datos públicos del grupo para la página de invitación
create or replace function public.get_group_public(p_slug text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare g public.groups;
begin
  select * into g from public.groups where slug = lower(btrim(coalesce(p_slug, '')));
  if not found then
    raise exception 'Este enlace de invitación no existe';
  end if;
  return public._group_public(g);
end;
$$;

-- Reclamar mi nombre: genera mi código personal. Solo se puede hacer una vez por nombre.
create or replace function public.join_group(p_slug text, p_participant_id uuid)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  g      public.groups;
  v_code text;
  v_name text;
begin
  select * into g from public.groups where slug = lower(btrim(coalesce(p_slug, '')));
  if not found then
    raise exception 'Este enlace de invitación no existe';
  end if;

  loop
    v_code := public._random_code(12);
    exit when not exists (select 1 from public.participants where access_code = v_code);
  end loop;

  update public.participants
     set access_code = v_code, joined_at = now()
   where id = p_participant_id and group_id = g.id and access_code is null
  returning name into v_name;

  if v_name is null then
    if exists (select 1 from public.participants where id = p_participant_id and group_id = g.id) then
      raise exception 'Esa persona ya se ha unido. Si eres tú, entra con tu enlace o código personal';
    end if;
    raise exception 'Ese participante no existe en este grupo';
  end if;

  return jsonb_build_object('code', v_code, 'name', v_name);
end;
$$;

-- Mi panel: mis datos, estado del grupo y quién se ha unido
create or replace function public.get_me(p_code text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  p public.participants;
  g public.groups;
begin
  select * into p from public.participants where access_code = public._normalize_code(p_code);
  if not found then
    raise exception 'Código personal no válido';
  end if;
  select * into g from public.groups where id = p.group_id;
  return jsonb_build_object(
    'me', jsonb_build_object(
      'id', p.id,
      'name', p.name,
      'code', p.access_code,
      'wishlist', jsonb_build_object(
        'wants', p.wish_wants, 'hobbies', p.wish_hobbies,
        'dislikes', p.wish_dislikes, 'about', p.wish_about)
    ),
    'group', public._group_public(g)
  );
end;
$$;

-- Mi resultado: SOLO a quién me toca regalar a mí (y su lista de deseos)
create or replace function public.get_my_result(p_code text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  p public.participants;
  g public.groups;
  r public.participants;
begin
  select * into p from public.participants where access_code = public._normalize_code(p_code);
  if not found then
    raise exception 'Código personal no válido';
  end if;
  select * into g from public.groups where id = p.group_id;
  if g.status <> 'drawn' then
    raise exception 'El sorteo todavía no se ha realizado';
  end if;
  select pr.* into r
    from public.assignments a
    join public.participants pr on pr.id = a.receiver_id
   where a.giver_id = p.id;
  return jsonb_build_object(
    'receiver', jsonb_build_object(
      'name', r.name,
      'wishlist', jsonb_build_object(
        'wants', r.wish_wants, 'hobbies', r.wish_hobbies,
        'dislikes', r.wish_dislikes, 'about', r.wish_about)
    ),
    'budget', g.budget,
    'delivery_date', g.delivery_date,
    'group_name', g.name
  );
end;
$$;

-- Editar mi lista de deseos (solo la mía)
create or replace function public.update_wishlist(
  p_code text, p_wants text, p_hobbies text, p_dislikes text, p_about text
)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare v_id uuid;
begin
  update public.participants
     set wish_wants    = left(btrim(coalesce(p_wants, '')), 1000),
         wish_hobbies  = left(btrim(coalesce(p_hobbies, '')), 1000),
         wish_dislikes = left(btrim(coalesce(p_dislikes, '')), 1000),
         wish_about    = left(btrim(coalesce(p_about, '')), 1000)
   where access_code = public._normalize_code(p_code)
  returning id into v_id;
  if v_id is null then
    raise exception 'Código personal no válido';
  end if;
  return jsonb_build_object('ok', true);
end;
$$;

-- ---------------------------------------------------------------------
-- Asistente de ideas de regalo (IA)
-- La función del servidor "gift-ideas" llama a esto para comprobar el código,
-- gastar 1 uso del límite diario y obtener los datos de tu amigo invisible.
-- ---------------------------------------------------------------------
create table if not exists public.ai_usage (
  participant_id uuid not null references public.participants(id) on delete cascade,
  day            date not null default current_date,
  uses           int  not null default 0,
  primary key (participant_id, day)
);
alter table public.ai_usage enable row level security;
revoke all on public.ai_usage from public;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    execute 'revoke all on public.ai_usage from anon';
  end if;
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on public.ai_usage from authenticated';
  end if;
end $$;

create or replace function public.gift_ideas_context(p_code text)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  p public.participants;
  g public.groups;
  r public.participants;
  v_uses int;
  daily_limit constant int := 20;
begin
  select * into p from public.participants where access_code = public._normalize_code(p_code);
  if not found then
    raise exception 'Código personal no válido';
  end if;
  select * into g from public.groups where id = p.group_id;
  if g.status <> 'drawn' then
    raise exception 'El sorteo todavía no se ha realizado';
  end if;

  insert into public.ai_usage (participant_id, day, uses) values (p.id, current_date, 1)
  on conflict (participant_id, day) do update set uses = public.ai_usage.uses + 1
  returning uses into v_uses;
  if v_uses > daily_limit then
    raise exception 'Has llegado al límite de % peticiones de ideas por hoy. Vuelve mañana.', daily_limit;
  end if;

  select pr.* into r
    from public.assignments a join public.participants pr on pr.id = a.receiver_id
   where a.giver_id = p.id;

  return jsonb_build_object(
    'receiver_name', r.name,
    'wishlist', jsonb_build_object('wants', r.wish_wants, 'hobbies', r.wish_hobbies,
                                   'dislikes', r.wish_dislikes, 'about', r.wish_about),
    'group_budget', g.budget,
    'uses_left', daily_limit - v_uses
  );
end;
$$;

-- Apartado público "Ideas de regalo" (sin grupo): límite por visitante y límite global diario.
-- Solo la función del servidor (rol service_role) puede llamarla: el navegador no.
create table if not exists public.ai_public_usage (
  client_hash text not null,               -- huella anónima (hash) del visitante, nunca su IP
  day         date not null default current_date,
  uses        int  not null default 0,
  primary key (client_hash, day)
);
alter table public.ai_public_usage enable row level security;
revoke all on public.ai_public_usage from public;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    execute 'revoke all on public.ai_public_usage from anon';
  end if;
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on public.ai_public_usage from authenticated';
  end if;
end $$;

create or replace function public.gift_ideas_public_quota(p_client text)
returns jsonb
language plpgsql
volatile
security definer
set search_path = public
as $$
declare
  per_visitor constant int := 10;   -- peticiones al día por visitante
  global_cap  constant int := 300;  -- peticiones al día en total (protege tu gasto)
  v_uses  int;
  v_total int;
begin
  if coalesce(p_client, '') = '' then
    raise exception 'Petición no válida';
  end if;
  -- limpieza de días anteriores
  delete from public.ai_public_usage where day < current_date - 2;

  select coalesce(sum(uses), 0) into v_total from public.ai_public_usage where day = current_date;
  if v_total >= global_cap then
    raise exception 'El asistente de ideas ha llegado a su límite de hoy. Vuelve mañana.';
  end if;

  insert into public.ai_public_usage (client_hash, day, uses) values (p_client, current_date, 1)
  on conflict (client_hash, day) do update set uses = public.ai_public_usage.uses + 1
  returning uses into v_uses;
  if v_uses > per_visitor then
    raise exception 'Has llegado al límite de % peticiones de ideas por hoy. Vuelve mañana.', per_visitor;
  end if;
  return jsonb_build_object('uses_left', per_visitor - v_uses);
end;
$$;

-- ---------------------------------------------------------------------
-- Permisos de ejecución: solo las funciones públicas son invocables
-- ---------------------------------------------------------------------
revoke execute on all functions in schema public from public;
do $$
declare
  fn text;
  pub text[] := array[
    'create_group(text, text[], numeric, date, boolean)',
    'admin_get_group(text)',
    'admin_add_participant(text, text)',
    'admin_remove_participant(text, uuid)',
    'admin_run_draw(text)',
    'admin_get_results(text)',
    'get_group_public(text)',
    'join_group(text, uuid)',
    'get_me(text)',
    'get_my_result(text)',
    'update_wishlist(text, text, text, text, text)',
    'gift_ideas_context(text)'
  ];
  internal text[] := array[
    '_random_code(int)', '_normalize_code(text)', '_clean_name(text)',
    '_group_by_admin(text)', '_participants_summary(uuid)', '_group_public(public.groups)',
    'gift_ideas_public_quota(text)'
  ];
begin
  foreach fn in array internal loop
    if exists (select 1 from pg_roles where rolname = 'anon') then
      execute format('revoke execute on function public.%s from anon', fn);
    end if;
    if exists (select 1 from pg_roles where rolname = 'authenticated') then
      execute format('revoke execute on function public.%s from authenticated', fn);
    end if;
  end loop;
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on function public.gift_ideas_public_quota(text) to service_role';
  end if;
  foreach fn in array pub loop
    if exists (select 1 from pg_roles where rolname = 'anon') then
      execute format('grant execute on function public.%s to anon', fn);
    end if;
    if exists (select 1 from pg_roles where rolname = 'authenticated') then
      execute format('grant execute on function public.%s to authenticated', fn);
    end if;
  end loop;
end $$;

-- Recarga la caché de la API de Supabase para que vea las funciones nuevas
notify pgrst, 'reload schema';
