import { Badge, Icon } from './ui'
import { formatDate, formatMoney } from './utils'

export const GroupMeta = ({ group, dark = true }) => {
  const tone = dark ? 'white' : 'muted'
  return (
    <div className="flex flex-wrap gap-2">
      <Badge tone={tone}><Icon.Euro className="h-3.5 w-3.5" /> Máx. {formatMoney(group.budget)}</Badge>
      {group.delivery_date && (
        <Badge tone={tone}><Icon.Calendar className="h-3.5 w-3.5" /> <span className="first-letter:uppercase">{formatDate(group.delivery_date)}</span></Badge>
      )}
      <Badge tone={tone}><Icon.Users className="h-3.5 w-3.5" /> {group.participants.length} participantes</Badge>
      {group.admin_can_see_results && (
        <Badge tone={dark ? 'white' : 'gold'}><Icon.Eye className="h-3.5 w-3.5" /> El organizador puede ver los resultados</Badge>
      )}
    </div>
  )
}

export function JoinProgress({ participants }) {
  const joined = participants.filter((p) => p.joined).length
  const total = participants.length
  const pct = total ? Math.round((joined / total) * 100) : 0
  return (
    <div>
      <div className="flex items-end justify-between">
        <p className="text-sm font-semibold text-white/90">
          <span className="text-2xl font-bold tabular-nums">{joined}</span>
          <span className="text-white/50">/{total}</span> se han unido
        </p>
        <span className="flex items-center gap-1.5 text-xs font-medium text-white/50">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-pine-600 opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-pine-600" />
          </span>
          En directo
        </span>
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-pine-600 to-gold-400 transition-all duration-700" style={{ width: `${pct}%` }} />
      </div>
    </div>
  )
}

export function ParticipantList({ participants, highlightId, onRemove, removingId }) {
  return (
    <ul className="divide-y divide-white/[0.07]">
      {participants.map((p) => (
        <li key={p.id} className="flex items-center justify-between gap-3 py-2.5">
          <div className="flex min-w-0 items-center gap-3">
            <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full text-sm font-bold ${p.joined ? 'bg-pine-600 text-white' : 'bg-white/[0.06] text-white/40'}`}>
              {p.name.trim()[0]?.toUpperCase()}
            </span>
            <span className="truncate font-medium text-white">
              {p.name}{p.id === highlightId && <span className="ml-1.5 text-xs font-semibold text-gold-400">(tú)</span>}
            </span>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            {p.joined
              ? <Badge tone="pine"><Icon.Check className="h-3.5 w-3.5" /> Confirmado</Badge>
              : <Badge tone="muted">Pendiente</Badge>}
            {onRemove && (
              <button
                onClick={() => onRemove(p)}
                disabled={removingId === p.id}
                aria-label={`Eliminar a ${p.name}`}
                className="grid h-8 w-8 place-items-center rounded-full text-white/30 transition hover:bg-berry-500/15 hover:text-berry-400 disabled:opacity-40"
              >
                <Icon.X className="h-4 w-4" />
              </button>
            )}
          </div>
        </li>
      ))}
    </ul>
  )
}

export function WishlistView({ wishlist, emptyText }) {
  const items = [
    { k: 'wants', label: 'Le gustaría recibir', icon: Icon.Gift },
    { k: 'hobbies', label: 'Aficiones', icon: Icon.Star },
    { k: 'dislikes', label: 'Mejor que no', icon: Icon.X },
    { k: 'about', label: 'Sobre sus gustos', icon: Icon.Heart },
  ].filter((i) => wishlist?.[i.k]?.trim())
  if (!items.length) return <p className="text-sm text-white/50">{emptyText}</p>
  return (
    <dl className="grid gap-3 sm:grid-cols-2">
      {items.map((i) => (
        <div key={i.k} className="rounded-2xl bg-ink-800 p-4 ring-1 ring-white/[0.08]">
          <dt className="flex items-center gap-2 text-xs font-bold tracking-wide text-pine-400 uppercase">
            <i.icon className="h-3.5 w-3.5" /> {i.label}
          </dt>
          <dd className="mt-1.5 text-sm whitespace-pre-line text-white">{wishlist[i.k]}</dd>
        </div>
      ))}
    </dl>
  )
}
