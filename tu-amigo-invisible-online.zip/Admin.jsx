import { useEffect, useState } from 'react'
import { Alert, Badge, Button, Card, CopyButton, ErrorScreen, Icon, LinkBox, Loading, Modal, WhatsAppButton, inputCls } from './ui'
import { GroupMeta, JoinProgress, ParticipantList } from './group'
import { api, isDemo } from './api'
import { navigate } from './router'
import { adminUrl, formatDate, formatMoney, inviteUrl, local, normalizeName, useLive } from './utils'

export default function Admin({ token, isNew }) {
  const { data: group, setData, error, loading } = useLive(() => api.adminGetGroup(token), 4000, [token])
  const [newName, setNewName] = useState('')
  const [actionError, setActionError] = useState('')
  const [busy, setBusy] = useState(false)
  const [removing, setRemoving] = useState(null)
  const [confirmDraw, setConfirmDraw] = useState(false)
  const [confirmRemove, setConfirmRemove] = useState(null)
  const [results, setResults] = useState(null)
  const [confirmResults, setConfirmResults] = useState(false)

  // recuerda el grupo en este dispositivo
  useEffect(() => { if (group) local.saveAdmin(group.slug, token, group.name) }, [group?.slug, group?.name, token])

  if (loading && !group) return <Loading />
  if (error && !group) return <ErrorScreen title="No encontramos este grupo" message={error.message} />

  const drawn = group.status === 'drawn'
  const total = group.participants.length
  const joined = group.participants.filter((p) => p.joined).length
  const pending = total - joined
  const invite = inviteUrl(group.slug)

  const inviteText =
    `🎁 ¡Te invito al amigo invisible "${group.name}"!\n\n` +
    `Presupuesto máximo: ${formatMoney(group.budget)}` +
    (group.delivery_date ? `\nEntrega: ${formatDate(group.delivery_date)}` : '') +
    `\n\nEntra aquí, elige tu nombre y descubre a quién te toca regalar:\n${invite}`

  const run = async (fn) => {
    setBusy(true); setActionError('')
    try { setData(await fn()) } catch (e) { setActionError(e.message) } finally { setBusy(false) }
  }

  const add = (e) => {
    e.preventDefault()
    const n = normalizeName(newName)
    if (!n) return
    run(async () => { const g = await api.adminAddParticipant(token, n); setNewName(''); return g })
  }

  const doRemove = async (p) => {
    setConfirmRemove(null); setRemoving(p.id); setActionError('')
    try { setData(await api.adminRemoveParticipant(token, p.id)) } catch (e) { setActionError(e.message) } finally { setRemoving(null) }
  }

  const doDraw = () => { setConfirmDraw(false); run(() => api.adminRunDraw(token)) }

  const loadResults = async () => {
    setConfirmResults(false); setActionError('')
    try { setResults(await api.adminGetResults(token)) } catch (e) { setActionError(e.message) }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5">
      <div className="animate-fade-up">
        <p className="text-sm font-semibold tracking-wide text-gold-400 uppercase">Panel del organizador</p>
        <h1 className="mt-1 font-display text-4xl font-semibold text-white sm:text-5xl">{group.name}</h1>
        <div className="mt-4"><GroupMeta group={group} /></div>
      </div>

      {isNew && !drawn && (
        <Alert tone="gold" className="animate-fade-up">
          <strong>¡Grupo creado!</strong> Ahora comparte la invitación. Si tú también participas, abre el enlace de invitación y elige tu nombre como uno más.
        </Alert>
      )}

      {/* Invitación */}
      <Card className="p-6 animate-fade-up sm:p-7">
        <div className="flex items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-[#25D366]/15 text-[#25D366]"><Icon.Users className="h-5 w-5" /></span>
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-xl font-semibold">Invita a los participantes</h2>
            <p className="mt-1 text-sm text-white/60">Envía este enlace al grupo de WhatsApp. Cada persona elegirá su nombre y recibirá su acceso privado.</p>
          </div>
        </div>
        <div className="mt-5 space-y-3">
          <LinkBox value={invite} />
          <div className="grid gap-3 sm:grid-cols-2">
            <WhatsAppButton text={inviteText}>Invitar por WhatsApp</WhatsAppButton>
            <CopyButton text={invite} label="Copiar enlace" />
          </div>
        </div>
      </Card>

      {isDemo && (
        <Card className="p-6 ring-gold-400/30 animate-fade-up sm:p-7">
          <h2 className="font-display text-lg font-semibold text-gold-300">Prueba la vista previa</h2>
          <p className="mt-1 text-sm text-white/60">Como aquí no hay otros móviles, puedes abrir la invitación en esta misma pantalla o simular que el resto se une.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Button variant="outline" onClick={() => navigate(`/g/${group.slug}`)}>Abrir la invitación aquí</Button>
            <Button variant="outline" disabled={drawn || pending === 0} onClick={() => run(() => api.demoJoinAll(token))}>Simular que se unen todos</Button>
          </div>
        </Card>
      )}

      {/* Participantes en directo */}
      <Card className="p-6 animate-fade-up sm:p-7">
        <div className="mb-5 flex items-center justify-between gap-3">
          <h2 className="font-display text-xl font-semibold">Participantes</h2>
          {drawn ? <Badge tone="pine"><Icon.Check className="h-3.5 w-3.5" /> Sorteo hecho</Badge> : <Badge tone="gold">{total}/50</Badge>}
        </div>
        <JoinProgress participants={group.participants} />
        <div className="mt-4">
          <ParticipantList
            participants={group.participants}
            onRemove={drawn ? null : (p) => (p.joined ? setConfirmRemove(p) : doRemove(p))}
            removingId={removing}
          />
        </div>
        {!drawn && (
          <form onSubmit={add} className="mt-4 flex gap-2">
            <input value={newName} onChange={(e) => setNewName(e.target.value)} maxLength={60} placeholder="Añadir a alguien más" aria-label="Nuevo participante" className={inputCls} disabled={total >= 50} />
            <Button type="submit" variant="dark" disabled={!newName.trim() || busy || total >= 50} aria-label="Añadir participante">
              <Icon.Plus className="h-5 w-5" />
            </Button>
          </form>
        )}
      </Card>

      {actionError && <Alert>{actionError}</Alert>}

      {/* Sorteo */}
      {!drawn ? (
        <Card className="overflow-hidden p-0 animate-fade-up">
          <div className="bg-gradient-to-br from-berry-700/25 via-ink-850 to-ink-900 p-6 text-white sm:p-8">
            <h2 className="font-display text-2xl font-semibold">Sorteo</h2>
            {total < 3 ? (
              <p className="mt-2 text-white/70">Necesitas al menos 3 participantes para sortear.</p>
            ) : pending === 0 ? (
              <p className="mt-2 text-white/70">¡Todos se han unido! Ya puedes hacer el sorteo.</p>
            ) : (
              <p className="mt-2 text-white/70">
                Faltan <strong className="text-gold-300">{pending}</strong> {pending === 1 ? 'persona' : 'personas'} por unirse. Puedes esperar o sortear ya: quienes falten verán su resultado cuando entren.
              </p>
            )}
            <Button
              size="xl"
              className="mt-6 w-full tracking-wide"
              disabled={total < 3}
              loading={busy}
              onClick={() => setConfirmDraw(true)}
            >
              <Icon.Shuffle className="h-6 w-6" /> REALIZAR SORTEO
            </Button>
            <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-white/50"><Icon.Lock className="h-3.5 w-3.5" /> Se hace en el servidor, una sola vez y de forma aleatoria</p>
          </div>
        </Card>
      ) : (
        <Card className="p-6 text-center animate-pop sm:p-8">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-pine-600 text-white"><Icon.Check className="h-7 w-7" /></div>
          <h2 className="mt-4 font-display text-2xl font-semibold">¡Sorteo realizado!</h2>
          <p className="mt-2 text-white/60">Cada participante ya puede ver a quién le toca regalar desde su enlace personal.</p>
          <div className="mt-5 flex flex-col justify-center gap-3 sm:flex-row">
            <WhatsAppButton text={`🎄 ¡Ya está hecho el sorteo del amigo invisible "${group.name}"!\n\nEntra y descubre a quién te toca:\n${invite}`}>Avisar por WhatsApp</WhatsAppButton>
          </div>
          {group.admin_can_see_results ? (
            results ? (
              <div className="mt-6 text-left">
                <h3 className="mb-2 font-semibold">Todos los resultados</h3>
                <ul className="divide-y divide-white/[0.07] rounded-2xl bg-ink-800 px-4 ring-1 ring-white/10">
                  {results.map((r) => (
                    <li key={r.giver} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                      <span className="font-medium">{r.giver}</span>
                      <Icon.Arrow className="h-4 w-4 shrink-0 text-gold-400" />
                      <span className="text-right font-medium">{r.receiver}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <Button variant="outline" className="mt-5" onClick={() => setConfirmResults(true)}><Icon.Eye className="h-4 w-4" /> Ver todos los resultados</Button>
            )
          ) : (
            <p className="mt-5 flex items-center justify-center gap-1.5 text-sm text-white/50"><Icon.Lock className="h-4 w-4" /> Ni siquiera tú puedes ver los resultados. Es secreto de verdad.</p>
          )}
        </Card>
      )}

      {/* Enlace del organizador */}
      <Card className="p-6 animate-fade-up sm:p-7">
        <div className="flex items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gold-400/15 text-gold-400"><Icon.Key className="h-5 w-5" /></span>
          <div>
            <h2 className="font-display text-xl font-semibold">Guarda tu enlace de organizador</h2>
            <p className="mt-1 text-sm text-white/60">Es la única forma de volver a este panel desde otro dispositivo. <strong>No lo compartas</strong>: quien lo tenga puede gestionar el grupo.</p>
          </div>
        </div>
        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <CopyButton text={adminUrl(token)} label="Copiar enlace de organizador" />
          <WhatsAppButton text={`🔑 Mi enlace de organizador del amigo invisible "${group.name}" (no compartir):\n${adminUrl(token)}`}>Enviármelo a mí</WhatsAppButton>
        </div>
      </Card>

      {/* Confirmaciones */}
      <Modal open={confirmDraw} onClose={() => setConfirmDraw(false)}>
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-berry-500/15 text-berry-400"><Icon.Shuffle className="h-7 w-7" /></div>
        <h3 className="mt-4 text-center font-display text-2xl font-semibold">¿Hacemos el sorteo?</h3>
        <p className="mt-2 text-center text-white/65">
          Se sortearán <strong>{total} participantes</strong>. El sorteo es <strong>definitivo</strong>: no se puede repetir ni añadir a nadie después.
          {pending > 0 && <> Todavía faltan {pending} por unirse.</>}
        </p>
        <div className="mt-6 grid gap-3">
          <Button size="lg" onClick={doDraw} loading={busy}>Sí, realizar sorteo</Button>
          <Button size="lg" variant="ghost" onClick={() => setConfirmDraw(false)}>Cancelar</Button>
        </div>
      </Modal>

      <Modal open={!!confirmRemove} onClose={() => setConfirmRemove(null)}>
        <h3 className="font-display text-2xl font-semibold">¿Eliminar a {confirmRemove?.name}?</h3>
        <p className="mt-2 text-white/65">Esta persona ya se había unido. Si la eliminas, su enlace personal dejará de funcionar.</p>
        <div className="mt-6 grid gap-3">
          <Button size="lg" onClick={() => doRemove(confirmRemove)}>Eliminar</Button>
          <Button size="lg" variant="ghost" onClick={() => setConfirmRemove(null)}>Cancelar</Button>
        </div>
      </Modal>

      <Modal open={confirmResults} onClose={() => setConfirmResults(false)}>
        <h3 className="font-display text-2xl font-semibold">¿Seguro que quieres verlos?</h3>
        <p className="mt-2 text-white/65">Verás quién regala a quién, incluido tu propio amigo invisible si participas. Se acabó la sorpresa.</p>
        <div className="mt-6 grid gap-3">
          <Button size="lg" variant="dark" onClick={loadResults}>Ver resultados</Button>
          <Button size="lg" variant="ghost" onClick={() => setConfirmResults(false)}>Mejor no</Button>
        </div>
      </Modal>
    </div>
  )
}
