import { useState } from 'react'
import { Alert, Button, Card, ErrorScreen, Icon, Loading, Modal, inputCls } from './ui'
import { GroupMeta, JoinProgress } from './group'
import { api } from './api'
import { navigate } from './router'
import { local, useLive } from './utils'

export default function Join({ slug }) {
  const { data: group, error, loading, refresh } = useLive(() => api.getGroupPublic(slug), 5000, [slug])
  const [selected, setSelected] = useState(null)
  const [joining, setJoining] = useState(false)
  const [joinError, setJoinError] = useState('')
  const [filter, setFilter] = useState('')
  const mine = local.memberFor(slug)

  if (loading && !group) return <Loading />
  if (error && !group) return <ErrorScreen title="Invitación no válida" message={error.message} />

  const available = group.participants.filter((p) => !p.joined)
  const visible = group.participants.filter((p) => p.name.toLowerCase().includes(filter.trim().toLowerCase()))

  const join = async () => {
    setJoining(true); setJoinError('')
    try {
      const res = await api.joinGroup(slug, selected.id)
      local.saveMember(slug, res.code, res.name, group.name)
      navigate(`/p/${res.code}?nuevo=1`)
    } catch (e) {
      setJoinError(e.message)
      setJoining(false)
      refresh()
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="text-center animate-fade-up">
        <p className="text-sm font-semibold tracking-wide text-gold-400 uppercase">Te han invitado a</p>
        <h1 className="mt-1 font-display text-4xl font-semibold text-white sm:text-5xl">{group.name}</h1>
        <div className="mt-4 flex justify-center"><GroupMeta group={group} /></div>
      </div>

      {mine && (
        <Card className="flex flex-col items-center justify-between gap-4 p-5 animate-fade-up sm:flex-row">
          <p className="text-sm text-white/70">Ya te has unido desde este dispositivo como <strong className="text-white">{mine.name}</strong>.</p>
          <Button variant="dark" onClick={() => navigate(`/p/${mine.code}`)}>Ir a mi panel <Icon.Arrow className="h-4 w-4" /></Button>
        </Card>
      )}

      <Card className="p-6 animate-fade-up sm:p-8">
        <h2 className="font-display text-2xl font-semibold">¿Quién eres?</h2>
        <p className="mt-1 text-sm text-white/60">Toca tu nombre. Solo podrás elegirlo una vez y después entrarás con tu enlace privado.</p>

        <div className="mt-5"><JoinProgress participants={group.participants} /></div>

        {group.participants.length > 10 && (
          <div className="relative mt-5">
            <Icon.Search className="pointer-events-none absolute top-1/2 left-4 h-4 w-4 -translate-y-1/2 text-white/40" />
            <input value={filter} onChange={(e) => setFilter(e.target.value)} placeholder="Busca tu nombre" aria-label="Buscar nombre" className={`${inputCls} pl-11`} />
          </div>
        )}

        {available.length === 0 ? (
          <Alert tone="pine" className="mt-5">Todos los participantes ya se han unido. Si eres uno de ellos, entra con tu enlace o código personal desde la página de inicio.</Alert>
        ) : (
          <div className="mt-5 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            {visible.map((p) => (
              <button
                key={p.id}
                disabled={p.joined}
                onClick={() => { setSelected(p); setJoinError('') }}
                className={`flex items-center justify-between rounded-2xl px-4 py-3.5 text-left font-semibold transition ${
                  p.joined
                    ? 'cursor-not-allowed bg-white/[0.04] text-white/35'
                    : 'bg-ink-800 text-white ring-1 ring-white/10 hover:-translate-y-0.5 hover:shadow-lg hover:ring-pine-600/40 active:translate-y-0'
                }`}
              >
                <span className="truncate">{p.name}</span>
                {p.joined
                  ? <span className="flex shrink-0 items-center gap-1 text-xs font-medium"><Icon.Check className="h-3.5 w-3.5" /> Ya unido</span>
                  : <Icon.Arrow className="h-4 w-4 shrink-0 text-white/30" />}
              </button>
            ))}
            {visible.length === 0 && <p className="col-span-full py-4 text-center text-sm text-white/50">No hay nadie con ese nombre.</p>}
          </div>
        )}
        {group.status === 'drawn' && available.length > 0 && (
          <p className="mt-5 text-center text-sm font-medium text-pine-400">El sorteo ya está hecho: en cuanto te unas verás tu resultado.</p>
        )}
      </Card>

      <p className="flex items-center justify-center gap-1.5 text-center text-xs text-white/50">
        <Icon.Lock className="h-3.5 w-3.5" /> Nadie puede ver a quién te toca, {group.admin_can_see_results ? 'salvo el organizador (lo activó al crear el grupo)' : 'ni siquiera el organizador'}.
      </p>

      <Modal open={!!selected} onClose={() => !joining && setSelected(null)}>
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-pine-600 text-2xl font-bold text-white">{selected?.name.trim()[0]?.toUpperCase()}</div>
        <h3 className="mt-4 text-center font-display text-2xl font-semibold">¿Eres {selected?.name}?</h3>
        <p className="mt-2 text-center text-white/65">Una vez confirmes, este nombre quedará vinculado a ti y nadie más podrá elegirlo.</p>
        {joinError && <Alert className="mt-4">{joinError}</Alert>}
        <div className="mt-6 grid gap-3">
          <Button size="lg" onClick={join} loading={joining}>Sí, soy yo</Button>
          <Button size="lg" variant="ghost" onClick={() => setSelected(null)} disabled={joining}>No, volver</Button>
        </div>
      </Modal>
    </div>
  )
}
