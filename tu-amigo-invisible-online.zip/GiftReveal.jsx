import { useEffect, useMemo, useState } from 'react'
import { Button, Icon } from './ui'
import { WishlistView } from './group'
import { formatDate, formatMoney } from './utils'

const COLORS = ['#e3b85a', '#f0d38b', '#d42f3c', '#ffffff', '#1d6a49']

function Confetti() {
  const pieces = useMemo(() => Array.from({ length: 36 }, (_, i) => {
    const angle = (Math.PI * 2 * i) / 36 + Math.random() * 0.3
    const dist = 90 + Math.random() * 120
    return {
      i,
      x: `${Math.cos(angle) * dist}px`,
      y: `${Math.sin(angle) * dist - 60}px`,
      r: `${Math.random() * 720 - 360}deg`,
      bg: COLORS[i % COLORS.length],
      delay: `${0.35 + Math.random() * 0.2}s`,
    }
  }), [])
  return pieces.map((p) => (
    <span key={p.i} className="confetti" style={{ background: p.bg, '--x': p.x, '--y': p.y, '--r': p.r, animationDelay: p.delay }} />
  ))
}

// result = { receiver: { name, wishlist }, budget, delivery_date }
export default function GiftReveal({ result, onClose }) {
  const [phase, setPhase] = useState('idle') // idle → opening → revealed
  const [round, setRound] = useState(0)

  useEffect(() => {
    if (phase !== 'opening') return
    const t = setTimeout(() => setPhase('revealed'), 1150)
    return () => clearTimeout(t)
  }, [phase])

  const replay = () => { setPhase('idle'); setRound((r) => r + 1); setTimeout(() => setPhase('opening'), 350) }

  return (
    <div className="text-center">
      {phase !== 'revealed' && (
        <div className="py-6">
          <div key={round} className={`gift ${phase}`}>
            <span className="gift-glow" />
            <div className="gift-lid"><span className="gift-bow" /></div>
            <div className="gift-box" />
            {phase === 'opening' && <Confetti />}
          </div>
          {phase === 'idle' && (
            <div className="mt-8 animate-fade-up">
              <p className="text-white/60">Tu amigo invisible está dentro…</p>
              <Button size="lg" className="mt-4" onClick={() => setPhase('opening')}>
                <Icon.Gift className="h-5 w-5" /> Abrir mi regalo
              </Button>
            </div>
          )}
        </div>
      )}

      {phase === 'revealed' && (
        <div className="animate-pop">
          <p className="text-sm font-bold tracking-[0.2em] text-gold-400 uppercase">¡Ya tienes tu amigo invisible!</p>
          <p className="mt-3 text-white/60">Te toca regalar a</p>
          <h2 data-testid="receiver-name" className="mt-1 font-display text-4xl leading-tight font-semibold text-white sm:text-5xl">{result.receiver.name}</h2>

          <div className="mx-auto mt-6 grid max-w-md grid-cols-2 gap-3">
            <div className="rounded-2xl bg-ink-800 p-4 ring-1 ring-white/10">
              <p className="flex items-center justify-center gap-1.5 text-xs font-semibold text-white/50 uppercase"><Icon.Euro className="h-3.5 w-3.5" /> Presupuesto</p>
              <p className="mt-1 text-xl font-bold text-white">{formatMoney(result.budget)}</p>
            </div>
            <div className="rounded-2xl bg-ink-800 p-4 ring-1 ring-white/10">
              <p className="flex items-center justify-center gap-1.5 text-xs font-semibold text-white/50 uppercase"><Icon.Calendar className="h-3.5 w-3.5" /> Entrega</p>
              <p className="mt-1 text-sm font-bold text-white first-letter:uppercase">{result.delivery_date ? formatDate(result.delivery_date) : 'Sin fecha fijada'}</p>
            </div>
          </div>

          <div className="mt-6 text-left">
            <h3 className="mb-3 text-center text-sm font-semibold text-white/90">Lista de deseos de {result.receiver.name.split(' ')[0]}</h3>
            <WishlistView wishlist={result.receiver.wishlist} emptyText={`${result.receiver.name.split(' ')[0]} todavía no ha escrito su lista de deseos. Vuelve a mirar más adelante.`} />
          </div>

          <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-white/50"><Icon.Lock className="h-3.5 w-3.5" /> Shhh… nadie más puede ver esto</p>
          <div className="mt-5 flex flex-col justify-center gap-3 sm:flex-row">
            <Button variant="outline" onClick={replay}><Icon.Refresh className="h-4 w-4" /> Volver a ver el resultado</Button>
            {onClose && <Button variant="ghost" onClick={onClose}>Ocultar</Button>}
          </div>
        </div>
      )}
    </div>
  )
}
