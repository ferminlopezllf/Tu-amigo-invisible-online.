import { useEffect, useRef, useState, useCallback } from 'react'

// ---------- Enlaces ----------
export const baseUrl = () => `${window.location.origin}${window.location.pathname}`
export const inviteUrl = (slug) => `${baseUrl()}#/g/${slug}`
export const personalUrl = (code) => `${baseUrl()}#/p/${code}`
export const adminUrl = (token) => `${baseUrl()}#/admin/${token}`
export const whatsappUrl = (text) => `https://wa.me/?text=${encodeURIComponent(text)}`

export const formatCode = (code = '') =>
  code.replace(/[^A-Za-z0-9]/g, '').toUpperCase().match(/.{1,4}/g)?.join('-') ?? ''

// ---------- Formato ----------
export const formatMoney = (n) =>
  new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: Number(n) % 1 ? 2 : 0 }).format(Number(n))

export const formatDate = (iso) => {
  if (!iso) return null
  const [y, m, d] = iso.split('-').map(Number)
  return new Intl.DateTimeFormat('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
    .format(new Date(y, m - 1, d))
}

export const normalizeName = (s) => s.replace(/\s+/g, ' ').trim()

// ---------- Portapapeles ----------
export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    const ta = document.createElement('textarea')
    ta.value = text
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    let ok = false
    try { ok = document.execCommand('copy') } catch { ok = false }
    document.body.removeChild(ta)
    return ok
  }
}

// ---------- Memoria local (este dispositivo) ----------
const KEY = 'amigo-invisible:v1'
const read = () => {
  try { return JSON.parse(localStorage.getItem(KEY)) || { admin: {}, member: {} } } catch { return { admin: {}, member: {} } }
}
const write = (v) => { try { localStorage.setItem(KEY, JSON.stringify(v)) } catch { /* modo privado */ } }

export const local = {
  all: read,
  saveAdmin(slug, token, name) {
    const s = read(); s.admin[slug] = { token, name, at: Date.now() }; write(s)
  },
  saveMember(slug, code, name, groupName) {
    const s = read(); s.member[slug] = { code, name, groupName, at: Date.now() }; write(s)
  },
  memberFor: (slug) => read().member[slug] || null,
}

// ---------- Datos que se refrescan solos ----------
// Vuelve a pedir los datos cada `interval` ms y al volver a la pestaña,
// así la lista de participantes y el estado del sorteo se actualizan solos.
export function useLive(fetcher, interval = 4000, deps = []) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [loading, setLoading] = useState(true)
  const fetcherRef = useRef(fetcher)
  fetcherRef.current = fetcher

  const refresh = useCallback(async () => {
    try {
      const d = await fetcherRef.current()
      setData(d)
      setError(null)
    } catch (e) {
      setError(e)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    setLoading(true)
    setData(null)
    refresh()
    const id = setInterval(() => { if (document.visibilityState === 'visible') refresh() }, interval)
    const onVis = () => { if (document.visibilityState === 'visible') refresh() }
    document.addEventListener('visibilitychange', onVis)
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', onVis) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)

  return { data, setData, error, loading, refresh }
}
