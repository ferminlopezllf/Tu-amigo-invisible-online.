import { useEffect, useState } from 'react'
import { Alert, Badge, Button, Card, CopyButton, ErrorScreen, Icon, Label, Loading, WhatsAppButton, inputCls } from './ui'
import { GroupMeta, JoinProgress, ParticipantList } from './group'
import GiftReveal from './GiftReveal'
import GiftIdeas from './GiftIdeas'
import { api } from './api'
import { formatCode, local, personalUrl, useLive } from './utils'

const FIELDS = [
  { k: 'wants', label: '¿Qué te gustaría recibir?', ph: 'Ej.: un libro de novela negra, una taza bonita, algo para la cocina…' },
  { k: 'hobbies', label: 'Tus aficiones', ph: 'Ej.: correr, series de misterio, cocinar, videojuegos…' },
  { k: 'dislikes', label: 'Cosas que NO quieres recibir', ph: 'Ej.: colonias, calcetines, chocolate…' },
  { k: 'about', label: 'Un poco sobre tus gustos', ph: 'Ej.: me encantan los colores neutros y todo lo relacionado con el café.' },
]

function WishlistForm({ code, initial }) {
  const [form, setForm] = useState(initial)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')
  const dirty = FIELDS.some((f) => (form[f.k] || '') !== (initial[f.k] || ''))

  const save = async (e) => {
    e.preventDefault()
    setSaving(true); setError('')
    try {
      await api.updateWishlist(code, form)
      setSaved(true); setTimeout(() => setSaved(false), 2500)
    } catch (err) { setError(err.message) } finally { setSaving(false) }
  }

  return (
    <form onSubmit={save} className="space-y-4">
      {FIELDS.map((f) => (
        <div key={f.k}>
          <Label htmlFor={`w-${f.k}`} hint="Opcional">{f.label}</Label>
          <textarea
            id={`w-${f.k}`}
            rows={2}
            maxLength={1000}
            value={form[f.k] || ''}
            onChange={(e) => { setForm({ ...form, [f.k]: e.target.value }); setSaved(false) }}
            placeholder={f.ph}
            className={`${inputCls} resize-y`}
          />
        </div>
      ))}
      {error && <Alert>{error}</Alert>}
      <Button type="submit" variant="dark" loading={saving} disabled={!dirty && !saved} className="w-full sm:w-auto">
        {saved ? <><Icon.Check className="h-4 w-4" /> Guardado</> : 'Guardar mi lista de deseos'}
      </Button>
    </form>
  )
}

export default function Me({ code, isNew }) {
  const { data, error, loading } = useLive(() => api.getMe(code), 5000, [code])
  const [result, setResult] = useState(null)
  const [showResult, setShowResult] = useState(false)
  const [resultError, setResultError] = useState('')
  const [loadingResult, setLoadingResult] = useState(false)

  useEffect(() => {
    if (data) local.saveMember(data.group.slug, data.me.code, data.me.name, data.group.name)
  }, [data?.me.code, data?.group.slug]) // eslint-disable-line react-hooks/exhaustive-deps

  if (loading && !data) return <Loading />
  if (error && !data) {
    return <ErrorScreen title="No encontramos tu acceso" message="El enlace o código no es válido. Revisa que esté completo o pide al organizador que te reenvíe la invitación." />
  }

  const { me, group } = data
  const drawn = group.status === 'drawn'
  const link = personalUrl(me.code)
  const first = me.name.split(' ')[0]

  const reveal = async () => {
    setLoadingResult(true); setResultError('')
    try {
      const r = result || await api.getMyResult(code)
      setResult(r); setShowResult(true)
    } catch (e) { setResultError(e.message) } finally { setLoadingResult(false) }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="animate-fade-up">
        <p className="text-sm font-semibold tracking-wide text-gold-400 uppercase">{group.name}</p>
        <h1 className="mt-1 font-display text-4xl font-semibold text-white sm:text-5xl">Hola, {first}</h1>
        <div className="mt-4"><GroupMeta group={group} /></div>
      </div>

      {/* Acceso personal (destacado la primera vez) */}
      <Card className={`p-6 animate-fade-up sm:p-7 ${isNew ? 'ring-4 ring-gold-400/60' : ''}`}>
        <div className="flex items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-gold-400/15 text-gold-400"><Icon.Key className="h-5 w-5" /></span>
          <div className="min-w-0">
            <h2 className="font-display text-xl font-semibold">{isNew ? '¡Ya estás dentro! Guarda tu acceso' : 'Tu acceso personal'}</h2>
            <p className="mt-1 text-sm text-white/60">Con este enlace o código puedes volver a entrar desde cualquier móvil u ordenador. Es solo tuyo: no lo compartas.</p>
          </div>
        </div>
        <div className="mt-5 rounded-2xl bg-ink-800 p-4 text-center ring-1 ring-white/10">
          <p className="text-xs font-semibold text-white/50 uppercase">Tu código</p>
          <p className="mt-1 font-mono text-2xl font-bold tracking-[0.18em] text-white select-all sm:text-3xl">{formatCode(me.code)}</p>
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <CopyButton text={link} label="Copiar mi enlace" />
          <WhatsAppButton text={`🔑 Mi acceso privado al amigo invisible "${group.name}" (no compartir):\n${link}\nCódigo: ${formatCode(me.code)}`}>Enviármelo a mí</WhatsAppButton>
        </div>
      </Card>

      {/* Resultado */}
      <Card className="overflow-hidden p-6 animate-fade-up sm:p-8">
        {!drawn ? (
          <div className="text-center">
            <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-pine-500/15 text-pine-400"><Icon.Gift className="h-7 w-7" /></div>
            <h2 className="mt-4 font-display text-2xl font-semibold">Esperando el sorteo</h2>
            <p className="mt-2 text-white/60">Cuando el organizador haga el sorteo, aquí aparecerá tu amigo invisible. No hace falta recargar la página.</p>
            <div className="mt-6 text-left"><JoinProgress participants={group.participants} /></div>
          </div>
        ) : showResult && result ? (
          <GiftReveal result={result} onClose={() => setShowResult(false)} />
        ) : (
          <div className="text-center">
            <Badge tone="berry" className="mb-3">¡Sorteo realizado!</Badge>
            <h2 className="font-display text-3xl font-semibold">Ya tienes tu amigo invisible</h2>
            <p className="mt-2 text-white/60">Asegúrate de que nadie está mirando tu pantalla…</p>
            {resultError && <Alert className="mt-4 text-left">{resultError}</Alert>}
            <Button size="xl" className="mt-6 w-full sm:w-auto" onClick={reveal} loading={loadingResult}>
              <Icon.Gift className="h-6 w-6" /> Descubrir a quién le regalo
            </Button>
          </div>
        )}
      </Card>

      {/* Ideas de regalo con IA (cuando ya sabes a quién regalas) */}
      {drawn && result && <GiftIdeas code={code} result={result} />}

      {/* Lista de deseos */}
      <Card className="p-6 animate-fade-up sm:p-8">
        <div className="mb-5 flex items-start gap-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-berry-500/15 text-berry-400"><Icon.Heart className="h-5 w-5" /></span>
          <div>
            <h2 className="font-display text-xl font-semibold">Tu lista de deseos</h2>
            <p className="mt-1 text-sm text-white/60">Ayuda a quien te toque. Solo la verá la persona que tiene que regalarte; puedes cambiarla cuando quieras.</p>
          </div>
        </div>
        <WishlistForm code={code} initial={me.wishlist} />
      </Card>

      {/* Participantes */}
      <Card className="p-6 animate-fade-up sm:p-8">
        <h2 className="mb-4 font-display text-xl font-semibold">Participantes</h2>
        {drawn && <div className="mb-4"><JoinProgress participants={group.participants} /></div>}
        <ParticipantList participants={group.participants} highlightId={me.id} />
      </Card>

      <p className="flex items-center justify-center gap-1.5 text-center text-xs text-white/50">
        <Icon.Lock className="h-3.5 w-3.5" /> Solo tú puedes ver a quién te toca, {group.admin_can_see_results ? 'y el organizador (lo activó al crear el grupo)' : 'ni siquiera el organizador puede verlo'}.
      </p>
    </div>
  )
}
