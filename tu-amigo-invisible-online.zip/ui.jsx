import { useEffect, useMemo, useState } from 'react'
import { copyText, whatsappUrl } from './utils'
import { isDemo } from './api'

// ---------------- Iconos ----------------
const svg = (path, props) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>{path}</svg>
)
export const Icon = {
  Gift: (p) => svg(<><rect x="3" y="8" width="18" height="4" rx="1" /><path d="M12 8v13M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5" /></>, p),
  Plus: (p) => svg(<path d="M12 5v14M5 12h14" />, p),
  X: (p) => svg(<path d="M18 6 6 18M6 6l12 12" />, p),
  Check: (p) => svg(<path d="M20 6 9 17l-5-5" />, p),
  Copy: (p) => svg(<><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></>, p),
  Users: (p) => svg(<><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" /></>, p),
  Lock: (p) => svg(<><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></>, p),
  Calendar: (p) => svg(<><rect x="3" y="4" width="18" height="18" rx="2" /><path d="M16 2v4M8 2v4M3 10h18" /></>, p),
  Euro: (p) => svg(<path d="M4 10h12M4 14h9M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 7.8 8 2 0 3.8-.8 5.2-2" />, p),
  Shuffle: (p) => svg(<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5" />, p),
  Star: (p) => svg(<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />, p),
  Arrow: (p) => svg(<path d="M5 12h14M12 5l7 7-7 7" />, p),
  Back: (p) => svg(<path d="M19 12H5M12 19l-7-7 7-7" />, p),
  Eye: (p) => svg(<><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" /><circle cx="12" cy="12" r="3" /></>, p),
  Heart: (p) => svg(<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />, p),
  Key: (p) => svg(<><circle cx="7.5" cy="15.5" r="5.5" /><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3" /></>, p),
  Alert: (p) => svg(<><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z" /><path d="M12 9v4M12 17h.01" /></>, p),
  Refresh: (p) => svg(<path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 3v5h-5M21 12a9 9 0 0 1-15 6.7L3 16M3 21v-5h5" />, p),
  Search: (p) => svg(<><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></>, p),
}

export const WhatsAppIcon = (props) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" {...props}>
    <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.61-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.07c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.79h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.86 9.86 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.89-9.88 2.64 0 5.12 1.03 6.99 2.9a9.82 9.82 0 0 1 2.89 6.99c0 5.45-4.43 9.88-9.88 9.88M20.46 3.49A11.82 11.82 0 0 0 12.05 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.95L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.45h.01c6.55 0 11.89-5.34 11.89-11.89 0-3.18-1.24-6.16-3.48-8.42" />
  </svg>
)

// ---------------- Básicos ----------------
const cx = (...c) => c.filter(Boolean).join(' ')

export function Button({ variant = 'primary', size = 'md', className, children, loading, ...props }) {
  const base = 'inline-flex items-center justify-center gap-2 rounded-2xl font-semibold transition-all duration-200 active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none focus:outline-none focus-visible:ring-4'
  const sizes = { sm: 'h-10 px-4 text-sm', md: 'h-12 px-5 text-[15px]', lg: 'h-14 px-7 text-base', xl: 'h-16 px-8 text-lg' }
  const variants = {
    primary: 'bg-berry-500 text-white shadow-lg shadow-berry-900/30 hover:bg-berry-600 focus-visible:ring-berry-500/40',
    gold: 'bg-gold-400 text-ink-950 shadow-lg shadow-gold-500/20 hover:bg-gold-300 focus-visible:ring-gold-400/40',
    dark: 'bg-gold-400 text-ink-950 hover:bg-gold-300 focus-visible:ring-gold-400/40',
    ghost: 'bg-transparent text-white/70 hover:bg-white/5 focus-visible:ring-pine-600/20',
    light: 'bg-white/10 text-white ring-1 ring-white/20 hover:bg-white/15 focus-visible:ring-white/30',
    outline: 'bg-ink-800 text-white ring-1 ring-white/15 hover:ring-white/30 hover:bg-ink-700 focus-visible:ring-pine-600/20',
    whatsapp: 'bg-[#25D366] text-white shadow-lg shadow-green-900/20 hover:bg-[#1ebe5a] focus-visible:ring-green-500/40',
  }
  return (
    <button className={cx(base, sizes[size], variants[variant], className)} disabled={loading || props.disabled} {...props}>
      {loading ? <Spinner className="h-5 w-5" /> : children}
    </button>
  )
}

export const Spinner = ({ className = 'h-6 w-6' }) => (
  <svg className={cx('animate-spin', className)} viewBox="0 0 24 24" fill="none" aria-label="Cargando">
    <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity=".25" strokeWidth="3" />
    <path d="M22 12a10 10 0 0 0-10-10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
  </svg>
)

export const Card = ({ className, children, ...p }) => (
  <div className={cx('rounded-3xl bg-ink-850 text-white shadow-2xl shadow-black/50 ring-1 ring-white/[0.07]', className)} {...p}>{children}</div>
)

export const Label = ({ children, hint, htmlFor }) => (
  <label htmlFor={htmlFor} className="mb-1.5 flex items-baseline justify-between gap-2 text-sm font-semibold text-white/90">
    <span>{children}</span>
    {hint && <span className="text-xs font-medium text-white/50">{hint}</span>}
  </label>
)

export const inputCls = 'w-full rounded-2xl border-0 bg-ink-800 px-4 py-3 text-[16px] text-white ring-1 ring-white/15 placeholder:text-white/35 [color-scheme:dark] transition focus:outline-none focus:ring-2 focus:ring-pine-600'

export const Badge = ({ tone = 'pine', children, className }) => {
  const tones = {
    pine: 'bg-pine-500/15 text-pine-400',
    gold: 'bg-gold-400/15 text-gold-300',
    berry: 'bg-berry-500/15 text-berry-400',
    white: 'bg-white/10 text-white ring-1 ring-white/15',
    muted: 'bg-white/5 text-white/60',
  }
  return <span className={cx('inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold', tones[tone], className)}>{children}</span>
}

export function Alert({ tone = 'berry', children, className }) {
  const tones = {
    berry: 'bg-berry-500/10 text-berry-300 ring-berry-500/30',
    gold: 'bg-gold-400/10 text-gold-100 ring-gold-400/30',
    pine: 'bg-pine-500/10 text-pine-300 ring-pine-500/30',
  }
  return (
    <div role="alert" className={cx('flex items-start gap-2.5 rounded-2xl px-4 py-3 text-sm font-medium ring-1', tones[tone], className)}>
      <Icon.Alert className="mt-0.5 h-4 w-4 shrink-0" />
      <div>{children}</div>
    </div>
  )
}

// ---------------- Copiar / compartir ----------------
export function CopyButton({ text, label = 'Copiar', variant = 'outline', size = 'md', className }) {
  const [done, setDone] = useState(false)
  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      onClick={async () => { if (await copyText(text)) { setDone(true); setTimeout(() => setDone(false), 1800) } }}
    >
      {done ? <Icon.Check className="h-4 w-4" /> : <Icon.Copy className="h-4 w-4" />}
      {done ? '¡Copiado!' : label}
    </Button>
  )
}

export const WhatsAppButton = ({ text, children = 'Compartir por WhatsApp', size = 'md', className }) => (
  <a
    href={whatsappUrl(text)}
    target="_blank"
    rel="noopener noreferrer"
    className={cx(
      'inline-flex items-center justify-center gap-2 rounded-2xl bg-[#25D366] font-semibold text-white shadow-lg shadow-green-900/20 transition hover:bg-[#1ebe5a] active:scale-[0.98]',
      size === 'lg' ? 'h-14 px-7 text-base' : 'h-12 px-5 text-[15px]',
      className,
    )}
  >
    <WhatsAppIcon className="h-5 w-5" />
    {children}
  </a>
)

export const LinkBox = ({ value }) => (
  <div className="truncate rounded-2xl bg-ink-800 px-4 py-3 font-mono text-[13px] text-white/80 ring-1 ring-white/10 select-all">{value}</div>
)

// ---------------- Modal ----------------
export function Modal({ open, onClose, children }) {
  useEffect(() => {
    if (!open) return
    const onKey = (e) => e.key === 'Escape' && onClose?.()
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = prev }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-6" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/75 backdrop-blur-sm animate-[fade-up_.25s_ease-out_both]" onClick={onClose} />
      <Card className="relative w-full max-w-md p-6 animate-pop sm:p-7">{children}</Card>
    </div>
  )
}

// ---------------- Estados ----------------
export const Loading = ({ text = 'Cargando…' }) => (
  <div className="flex flex-col items-center justify-center gap-3 py-24 text-white/70">
    <Spinner className="h-8 w-8 text-gold-400" />
    <p className="text-sm">{text}</p>
  </div>
)

export const ErrorScreen = ({ title = 'Algo no ha ido bien', message, action }) => (
  <div className="mx-auto max-w-md py-16 animate-fade-up">
    <Card className="p-8 text-center">
      <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-berry-500/15 text-berry-400">
        <Icon.Alert className="h-7 w-7" />
      </div>
      <h1 className="font-display text-2xl font-semibold">{title}</h1>
      {message && <p className="mt-2 text-white/70">{message}</p>}
      <div className="mt-6 flex justify-center gap-3">
        {action}
        <a href="#/" className="inline-flex h-12 items-center rounded-2xl px-5 font-semibold text-pine-400 hover:bg-white/5">Ir al inicio</a>
      </div>
    </Card>
  </div>
)

// ---------------- Decoración ----------------
export function Snow({ count = 28 }) {
  const flakes = useMemo(() => Array.from({ length: count }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    size: 2 + Math.random() * 3.5,
    duration: 12 + Math.random() * 16,
    delay: -Math.random() * 25,
    opacity: 0.15 + Math.random() * 0.35,
    drift: (Math.random() - 0.5) * 80,
  })), [count])
  return (
    <div aria-hidden="true">
      {flakes.map((f) => (
        <span
          key={f.id}
          className="snowflake"
          style={{
            left: `${f.left}%`, width: f.size, height: f.size, opacity: f.opacity,
            animationDuration: `${f.duration}s`, animationDelay: `${f.delay}s`, '--drift': `${f.drift}px`,
          }}
        />
      ))}
    </div>
  )
}

export const Logo = () => (
  <a href="#/" className="group inline-flex items-center gap-2.5">
    <span className="grid h-9 w-9 place-items-center rounded-xl bg-berry-500 text-white shadow-lg shadow-berry-900/40 transition group-hover:rotate-[-6deg]">
      <Icon.Gift className="h-5 w-5" />
    </span>
    <span className="font-display text-lg font-semibold tracking-tight text-white">
      Amigo Invisible <span className="text-gold-400">Online</span>
    </span>
  </a>
)

// Guirnalda de luces muy sutil en la parte superior
const BULBS = ['#d42f3c', '#e3b85a', '#2f9e6b', '#f0d38b']
export function Garland() {
  const n = 22
  // Dos curvas colgando: y = 6 + 24 * t(1-t) en cada mitad (igual que el cable)
  const pts = Array.from({ length: n }, (_, i) => {
    const xf = (i + 0.5) / n
    const t = (xf % 0.5) / 0.5
    return { left: xf * 100, top: 6 + 24 * 2 * t * (1 - t) - 1, c: BULBS[i % BULBS.length], d: (i * 0.37) % 3.2 }
  })
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-8 opacity-75" aria-hidden="true">
      <svg viewBox="0 0 1000 34" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        <path d="M0 6 Q250 30 500 6 Q750 30 1000 6" fill="none" stroke="rgba(255,255,255,.13)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
      </svg>
      {pts.map((p, i) => (
        <span
          key={i}
          className="bulb absolute h-[5px] w-[5px] -translate-x-1/2 rounded-full"
          style={{ left: `${p.left}%`, top: `${(p.top / 34) * 100}%`, background: p.c, boxShadow: `0 0 8px 2px ${p.c}55`, animationDelay: `${p.d}s` }}
        />
      ))}
    </div>
  )
}

const Holly = (p) => (
  <svg viewBox="0 0 32 20" aria-hidden="true" {...p}>
    <path d="M15 11c-3-6-9-7-13-5 2 1 2 3 1 4 2 0 3 2 2 4 3-2 7-2 10-3z" fill="#1d6a49" />
    <path d="M17 11c3-6 9-7 13-5-2 1-2 3-1 4-2 0-3 2-2 4-3-2-7-2-10-3z" fill="#2f9e6b" />
    <circle cx="14" cy="12.5" r="2.4" fill="#d42f3c" /><circle cx="18" cy="12.5" r="2.4" fill="#b3202e" /><circle cx="16" cy="9.5" r="2.4" fill="#e9434f" />
  </svg>
)

export const Layout = ({ children }) => (
  <div className="relative min-h-dvh overflow-x-hidden">
    <Snow />
    {isDemo && (
      <div className="relative z-20 border-b border-gold-400/20 bg-gold-400/10 px-4 py-2 text-center text-xs font-medium text-gold-100">
        Vista previa · Los datos se guardan solo en este navegador. Para usarla con tus amigos, publícala con Supabase (README).
      </div>
    )}
    <div className="relative">
      <Garland />
    </div>
    <header className="relative z-10 mx-auto flex max-w-5xl items-center justify-between px-5 pt-5 sm:px-8 sm:pt-7">
      <Logo />
    </header>
    <main className="relative z-10 mx-auto max-w-5xl px-4 pb-20 pt-6 sm:px-8 sm:pt-10">{children}</main>
    <footer className="relative z-10 flex flex-col items-center gap-2 pb-8 text-center text-xs text-white/40">
      <Holly className="h-5 w-8 opacity-80" />
      Felices fiestas · Los resultados son privados
    </footer>
  </div>
)
