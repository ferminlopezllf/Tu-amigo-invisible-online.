import { demoApi } from './demo'
// Cliente mínimo para las funciones (RPC) de Supabase.
// Toda la lógica sensible vive en la base de datos (supabase/schema.sql):
// el navegador nunca lee las tablas directamente.

const URL = (import.meta.env.VITE_SUPABASE_URL || '').replace(/\/+$/, '')
const KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || ''

export const isDemo = import.meta.env.VITE_DEMO === '1'
export const isConfigured = isDemo || Boolean(URL && KEY)

export const supabaseUrl = URL
export function supabaseHeaders() {
  const headers = { apikey: KEY, 'Content-Type': 'application/json' }
  // Las claves "anon" antiguas son JWT (empiezan por eyJ); las nuevas "publishable" no.
  if (KEY.startsWith('eyJ')) headers.Authorization = `Bearer ${KEY}`
  return headers
}

async function rpc(fn, params = {}) {
  const headers = supabaseHeaders()

  let res
  try {
    res = await fetch(`${URL}/rest/v1/rpc/${fn}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    })
  } catch {
    throw new Error('No se pudo conectar. Revisa tu conexión a internet e inténtalo de nuevo.')
  }

  const text = await res.text()
  let data = null
  try { data = text ? JSON.parse(text) : null } catch { data = text }

  if (!res.ok) {
    const msg = (data && data.message) || 'Ha ocurrido un error inesperado.'
    const err = new Error(msg)
    err.status = res.status
    throw err
  }
  return data
}

const realApi = {
  createGroup: ({ name, participants, budget, deliveryDate, adminCanSeeResults }) =>
    rpc('create_group', {
      p_name: name,
      p_participants: participants,
      p_budget: budget,
      p_delivery_date: deliveryDate || null,
      p_admin_can_see_results: adminCanSeeResults,
    }),
  adminGetGroup: (token) => rpc('admin_get_group', { p_admin_token: token }),
  adminAddParticipant: (token, name) => rpc('admin_add_participant', { p_admin_token: token, p_name: name }),
  adminRemoveParticipant: (token, id) => rpc('admin_remove_participant', { p_admin_token: token, p_participant_id: id }),
  adminRunDraw: (token) => rpc('admin_run_draw', { p_admin_token: token }),
  adminGetResults: (token) => rpc('admin_get_results', { p_admin_token: token }),
  getGroupPublic: (slug) => rpc('get_group_public', { p_slug: slug }),
  joinGroup: (slug, participantId) => rpc('join_group', { p_slug: slug, p_participant_id: participantId }),
  getMe: (code) => rpc('get_me', { p_code: code }),
  getMyResult: (code) => rpc('get_my_result', { p_code: code }),
  updateWishlist: (code, w) =>
    rpc('update_wishlist', {
      p_code: code,
      p_wants: w.wants,
      p_hobbies: w.hobbies,
      p_dislikes: w.dislikes,
      p_about: w.about,
    }),
}

export const api = isDemo ? demoApi : realApi
