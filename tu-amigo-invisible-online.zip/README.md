# 🎁 Amigo Invisible Online

Web para organizar un amigo invisible de hasta 50 personas sin reunirse. Cada participante entra desde su móvil, elige su nombre, recibe un acceso privado y descubre solo a quién le toca regalar.

**Tecnologías:** React + Tailwind CSS (frontend) · Supabase / PostgreSQL (base de datos, seguridad y sorteo en el servidor).

---

## Cómo poner la web online (paso a paso, sin instalar nada)

Vas a usar tres servicios gratuitos:

- **Supabase**: guarda los datos.
- **GitHub**: guarda el código.
- **Vercel**: publica la web.

Tardarás unos 15 minutos.

### Paso 1 — Crear la base de datos en Supabase

1. Entra en <https://supabase.com> y crea una cuenta. Puedes entrar con GitHub.
2. Pulsa **New project**.
   - Ponle un nombre, por ejemplo `amigo-invisible`.
   - Inventa una contraseña de base de datos y guárdala. No la usarás en la web.
   - En **Region**, elige una de Europa, por ejemplo *West EU (Ireland)* o *Central EU (Frankfurt)*.
3. Espera 1–2 minutos a que el proyecto termine de crearse.
4. En el menú de la izquierda abre **SQL Editor**, y después **New query**.
5. Abre el archivo `schema.sql` de este proyecto, copia **todo** su contenido, pégalo en el editor y pulsa **Run**.
   - Debe aparecer *Success. No rows returned*.
   - Esto crea las tablas, la seguridad y el sistema de sorteo.
6. Busca tus dos datos de conexión en **Project Settings → API** (o **Data API / API Keys**, según la versión del panel):
   - **Project URL**: algo como `https://abcdefgh.supabase.co`.
   - **Clave pública**: se llama `anon public` o `publishable` y empieza por `eyJ…` o por `sb_publishable_…`.

   ⚠️ No uses nunca la clave `service_role` ni la `secret`. Esas son privadas.

### Paso 2 — Subir el código a GitHub

1. Crea una cuenta en <https://github.com> si no tienes.
2. Pulsa **+ → New repository**, ponle de nombre `amigo-invisible` y pulsa **Create repository**.
3. En la página del repositorio vacío, pulsa **uploading an existing file**.
4. Descomprime el zip en tu ordenador. Arrastra **el contenido de la carpeta** (no la carpeta entera): `src`, `public`, `supabase`, `index.html`, `package.json`, `vite.config.js`, etc.
5. Pulsa **Commit changes**.

### Paso 3 — Publicar la web en Vercel

1. Entra en <https://vercel.com> y regístrate con **Continue with GitHub**.
2. Pulsa **Add New… → Project** e importa el repositorio `amigo-invisible`.
3. Vercel detecta solo que es un proyecto **Vite**. No cambies nada de la configuración de compilación.
4. Despliega el apartado **Environment Variables** y añade estas dos:

   | Name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | tu Project URL del paso 1 |
   | `VITE_SUPABASE_ANON_KEY` | tu clave pública del paso 1 |

5. Pulsa **Deploy** y espera alrededor de un minuto.
6. Recibirás una dirección del tipo `https://amigo-invisible-xxxx.vercel.app`. **Esa es tu web.** 🎉

> Si cambias las variables más tarde, en Vercel ve a **Deployments**, abre los tres puntos del último despliegue y pulsa **Redeploy**.

### Paso 4 — Usarla con tus amigos

1. Abre tu web y pulsa **Crear un amigo invisible**.
2. Añade a los participantes con nombre y apellido, el presupuesto y la fecha.
3. En el panel del organizador:
   - Pulsa **Invitar por WhatsApp** y envía el enlace al grupo.
   - Pulsa **Enviármelo a mí** para guardar tu enlace de organizador.
4. Cada persona abre el enlace, toca su nombre y confirma. Recibe un **enlace y un código personal** con los que puede volver a entrar desde cualquier dispositivo.
5. En tu panel verás en directo quién se ha unido. Cuando quieras, pulsa **REALIZAR SORTEO**.
6. Cada participante pulsa **Descubrir a quién le regalo** y ve su resultado y la lista de deseos de esa persona.

Si tú también participas, únete con el enlace de invitación como uno más. Así tampoco tú sabrás nada de los demás.

### Paso 5 — Activar las ideas de regalo con IA (opcional)

La web tiene dos sitios donde la IA (Claude) propone regalos. En ambos se puede elegir un **precio máximo** o un **intervalo** (por ejemplo, entre 20 y 40 €):

- **Apartado "Ideas de regalo"**, desde la página de inicio. Lo puede usar cualquiera, sin grupo. Describe a la persona y su personalidad, marca rasgos y elige el precio.
- **Tras el sorteo:** cada participante tiene un asistente que además usa la lista de deseos de su amigo invisible.

Necesitas una clave de la API de Anthropic. Se paga por uso, aunque cada consulta cuesta muy poco. Para que el gasto nunca se dispare, la web aplica estos límites:

| Quién | Límite |
|---|---|
| Participante de un grupo | 20 peticiones al día |
| Visitante del apartado público | 10 peticiones al día |
| Todo el apartado público junto | 300 peticiones al día |

Puedes cambiar estos números en `schema.sql`: busca `daily_limit`, `per_visitor` y `global_cap`.

1. **Consigue la clave.**
   - Entra en <https://console.anthropic.com>, crea una cuenta y añade algo de saldo en *Billing*.
   - En **API Keys**, pulsa **Create Key** y copia la clave (empieza por `sk-ant-`).
   - Es privada: no la pongas nunca en Vercel ni en el código.
2. **Crea la función en Supabase.**
   - En el panel de Supabase, abre **Edge Functions** y crea una función nueva con el editor del navegador (*Deploy a new function → Via Editor*).
   - Llámala exactamente `gift-ideas`.
   - Borra el código de ejemplo, pega el contenido de `gift-ideas-function.ts` y pulsa **Deploy**.
3. **Desactiva la verificación JWT.**
   - En los ajustes de la función (*Details* o *Settings*), desactiva **Verify JWT** / *Enforce JWT verification* y guarda.
   - Es seguro: la función comprueba el código personal de cada participante.
4. **Guarda la clave como secreto.**
   - En **Edge Functions → Secrets**, añade un secreto con el nombre `ANTHROPIC_API_KEY` y la clave como valor.
5. **Actualiza la base de datos.**
   - Si ejecutaste `schema.sql` antes de esta versión, vuelve a pegarlo y pulsa **Run**. Añade los contadores de uso de la IA y no borra nada.

Si no haces este paso, la web funciona igual. Solo las ideas de regalo mostrarán un aviso de que no están activadas.

---

## Seguridad y privacidad: cómo funciona

- El navegador **no puede leer las tablas**: tienen RLS activado y ninguna política, y además se han revocado los permisos. Todo pasa por funciones del servidor que comprueban tu código y solo devuelven lo que te corresponde.
- **El sorteo se hace en la base de datos.** Baraja de forma aleatoria y uniforme hasta que nadie se tiene a sí mismo, y bloquea el grupo mientras sortea. Así no se puede ejecutar dos veces, ni siquiera pulsando a la vez desde dos móviles.
- La base de datos garantiza que **cada uno regala una vez, recibe una vez y nunca a sí mismo**, mediante restricciones `PRIMARY KEY`, `UNIQUE` y `CHECK`.
- Cada participante tiene un **código personal aleatorio de 12 caracteres** (unos 60 bits). Un nombre solo se puede reclamar una vez.
- **El organizador no ve los resultados**, salvo que active la opción al crear el grupo. Esa opción no se puede cambiar después y todos los participantes ven si está activa.
- Las **listas de deseos** solo las ve su dueño y quien le tiene que regalar.
- **Asistente de IA:** la clave de Anthropic solo está en el servidor de Supabase. La función solo responde a quien tenga un código personal válido, una vez hecho el sorteo, y solo usa los datos de *su* amigo invisible. Tiene un límite de 20 peticiones al día por participante.
- **Ideas públicas:** cada visitante se identifica con una huella anónima (un *hash*), nunca con su IP en claro. Los contadores solo los puede tocar el servidor.

---

## Preguntas frecuentes

**Alguien ha perdido su enlace.** Puede entrar con su código en la página de inicio, en el apartado "¿Ya participas en un grupo?". Si ha perdido también el código, no hay forma de recuperarlo, a propósito, para que nadie pueda suplantarle. Antes del sorteo, el organizador puede eliminar a esa persona y volver a añadirla para que se una de nuevo.

**Alguien eligió el nombre equivocado.** Antes del sorteo, el organizador elimina ese nombre y lo vuelve a añadir.

**¿Se actualiza solo?** Sí. Los paneles consultan el servidor cada 4–5 segundos y al volver a la pestaña, así que no hace falta recargar.

**¿Cuesta dinero?** Con el plan gratuito de Supabase y de Vercel es suficiente. Supabase **pausa los proyectos gratuitos tras una semana sin actividad**. Si pasa, entra en el panel de Supabase y pulsa **Restore project**. Los datos no se pierden.

**¿Puedo usar mi propio dominio?** Sí. En Vercel, ve a **Settings → Domains**.

---

## Desarrollo en tu ordenador (opcional)

Necesitas [Node.js](https://nodejs.org) 20 o superior.

```bash
npm install
cp .env.example .env      # y rellena tus datos de Supabase
npm run dev               # abre http://localhost:5173
npm run build             # genera la versión final en /dist
```

## Estructura

Todos los archivos están en un mismo nivel (sin carpetas), para subirlos fácilmente a GitHub arrastrándolos.

```
schema.sql                 Base de datos, seguridad y sorteo (pegar en Supabase)
gift-ideas-function.ts     Función del servidor para las ideas de regalo con IA (pegar en Supabase)
index.html, main.jsx       Entrada de la web
App.jsx, router.js         Páginas y navegación
Home.jsx                   Página principal
CreateGroup.jsx            Crear grupo
Admin.jsx                  Panel del organizador
Join.jsx                   Página de invitación ("¿Quién eres?")
Me.jsx                     Panel del participante
Ideas.jsx, GiftIdeas.jsx   Ideas de regalo con IA
api.js, ai.js, ...         Conexión con Supabase y la IA
```
